/* Sprich — service worker: يعمل التطبيق بدون إنترنت بعد أول زيارة
   لتحديث الملفات للجميع غيّر رقم VERSION. */
const VERSION = 'sprich-v5';
const SHELL = [
  '/', '/index.html', '/lessons.html', '/search.html', '/lesson.html', '/about.html', '/contact.html', '/privacy.html', '/terms.html',
  '/explain.html', '/install.html', '/placement.html', '/achievements.html', '/shadowing.html',
  '/assets/style.css', '/assets/config.js', '/assets/site.js', '/assets/lessons.js', '/assets/voices.js', '/assets/engine.js', '/assets/tts.js', '/assets/games.js',
  '/lessons/index.json', '/manifest.webmanifest',
  '/assets/icons/icon-192.png', '/assets/icons/icon-512.png', '/assets/icons/favicon.svg'
];
/* مصادر خارجية نخزّنها للعمل دون اتصال (الخطوط والأيقونات ومكتبة الأصوات) */
const CDN = ['fonts.googleapis.com', 'fonts.gstatic.com', 'cdnjs.cloudflare.com', 'cdn.jsdelivr.net'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => Promise.all(SHELL.map(u => c.add(u).catch(() => {})))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

function swr(req, opts) {
  return caches.open(VERSION).then(c => c.match(req, opts).then(hit => {
    const net = fetch(req).then(res => { if (res && (res.ok || res.type === 'opaque')) c.put(req, res.clone()); return res; }).catch(() => hit);
    return hit || net;
  }));
}
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin === location.origin) {
    if (url.pathname === '/sw.js' || url.pathname.indexOf('/downloads/') === 0 || url.pathname.indexOf('/.well-known/') === 0 || url.pathname === '/assetlinks.json') return;
    if (req.mode === 'navigate') {
      /* الصفحات: الشبكة أولًا ثم النسخة المخزّنة (lesson.html يصلح لأي ?l=) */
      e.respondWith(fetch(req).then(res => { const cp = res.clone(); caches.open(VERSION).then(c => c.put(req, cp)); return res; })
        .catch(() => caches.match(req, { ignoreSearch: true }).then(h => h || caches.match('/index.html'))));
      return;
    }
    /* الدروس: تحديث في الخلفية مع عرض النسخة المخزّنة فورًا */
    e.respondWith(swr(req));
    return;
  }
  if (CDN.includes(url.hostname)) e.respondWith(swr(req));
});
