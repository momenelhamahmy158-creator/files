/* ================================================================
   Sprich — سلوك الموقع العام: القائمة، الوضع الداكن، المؤقت، الكشكول، PWA
   ================================================================ */
(function () {
  'use strict';
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var LS = { get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };
  var SS = { get: function (k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }, set: function (k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} } };

  /* ----- روابط المنصة ----- */
  var LINKS = window.SX_LINKS || {};
  document.querySelectorAll('[data-slot]').forEach(function (a) {
    var v = LINKS[a.getAttribute('data-slot')];
    if (v) a.setAttribute('href', v);
  });
  /* منع القفز لأعلى عند الضغط على رابط «#» فقط. نفحص الرابط وقت الضغط لا وقت التحميل،
     لأن بعض الصفحات (التحميل واتصل بنا) تضع الرابط الحقيقي بعد تحميل الصفحة */
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a') : null;
    if (a && a.getAttribute('href') === '#') e.preventDefault();
  });

  /* ================= المؤقت: وقت الجلسة + إجمالي اليوم (يعمل في كل الصفحات) ================= */
  var today = new Date().toISOString().slice(0, 10);
  var sess = +SS.get('spSess') || 0, day = JSON.parse(LS.get('spDay') || 'null');
  if (!day || day.d !== today) day = { d: today, s: 0 };
  var running = SS.get('spRun') !== '0', lastTick = Date.now(), saveAt = 0;
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmt(s) { return pad(Math.floor(s / 3600)) + ':' + pad(Math.floor(s % 3600 / 60)) + ':' + pad(s % 60); }
  function save() { SS.set('spSess', String(sess)); LS.set('spDay', JSON.stringify(day)); }
  function paintTimer() {
    var t = fmt(sess), m = $('sxMenuTimer'), b = $('spClock'), pl = $('spPillT');
    if (m) m.textContent = t;
    if (pl) pl.textContent = t;
    if (b) b.textContent = t;
    var dd = $('spToday'); if (dd) dd.textContent = 'اليوم: ' + Math.floor(day.s / 3600) + ' س ' + Math.floor(day.s % 3600 / 60) + ' د';
    var pb = $('spPause'); if (pb) pb.innerHTML = running ? '<i class="fas fa-pause"></i> إيقاف مؤقت' : '<i class="fas fa-play"></i> استئناف';
  }
  setInterval(function () {
    var now = Date.now(), dt = Math.min(2, Math.round((now - lastTick) / 1000)); lastTick = now;
    if (running && !document.hidden && dt > 0) { sess += dt; day.s += dt; if (now - saveAt > 5000) { save(); saveAt = now; } }
    paintTimer();
  }, 1000);
  window.addEventListener('pagehide', save);
  paintTimer();

  function modal(id, html) {
    var m = $(id);
    if (!m) {
      m = document.createElement('div'); m.className = 'sp-modal'; m.id = id; m.setAttribute('dir', 'rtl');
      m.innerHTML = '<div class="sp-box"><button type="button" class="sp-x" aria-label="إغلاق"><i class="fas fa-times"></i></button>' + html + '</div>';
      m.addEventListener('click', function (e) { if (e.target === m) m.classList.remove('on'); });
      m.querySelector('.sp-x').addEventListener('click', function () { m.classList.remove('on'); });
      document.body.appendChild(m);
      return { el: m, fresh: true };
    }
    return { el: m, fresh: false };
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') document.querySelectorAll('.sp-modal.on').forEach(function (m) { m.classList.remove('on'); }); });

  function openTimer() {
    var r = modal('spTimer', '<h3><i class="fas fa-stopwatch"></i> وقت الجلسة</h3><div class="sp-clock" id="spClock">00:00:00</div><div class="sp-sub" id="spToday"></div>' +
      '<div class="sp-row"><button type="button" class="sp-btn" id="spPause"></button><button type="button" class="sp-btn alt" id="spReset"><i class="fas fa-rotate-left"></i> تصفير الجلسة</button></div>' +
      '<div class="sp-row" style="margin-top:12px"><button type="button" class="sp-btn" id="spEnd" style="background:#111"><i class="fas fa-qrcode"></i> إنهاء الجلسة وحفظ الباركود</button></div>' +
      '<p class="sp-sub" style="margin:14px 0 0;font-size:.85rem">يُحفظ الباركود كصورة، وترفعها لاحقًا في صفحة «إنجازاتي» لتحسب إنجازاتك.</p>');
    if (r.fresh) {
      $('spPause').addEventListener('click', function () { running = !running; SS.set('spRun', running ? '1' : '0'); lastTick = Date.now(); paintTimer(); });
      $('spReset').addEventListener('click', function () { sess = 0; save(); paintTimer(); });
      $('spEnd').addEventListener('click', endSession);
    }
    paintTimer(); r.el.classList.add('on');
  }


  /* ================= إنهاء الجلسة وحفظ باركود الإنجاز ================= */
  function loadQR(cb) {
    if (window.QRCode) return cb();
    var s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js';
    s.onload = cb; s.onerror = function () { alert('تعذّر تحميل مولّد الباركود. تحقّق من الاتصال وأعد المحاولة.'); };
    document.head.appendChild(s);
  }
  function endSession() {
    if (sess < 5) { alert('الجلسة قصيرة جدًا — تعلّم قليلًا ثم احفظها.'); return; }
    var data = { sessionId: 'S' + Date.now(), duration: sess, date: new Date().toISOString(), url: location.origin };
    var mins = Math.max(1, Math.round(sess / 60));
    loadQR(function () {
      var box = document.createElement('div'); box.style.cssText = 'position:fixed;left:-9999px;top:0'; document.body.appendChild(box);
      new QRCode(box, { text: JSON.stringify(data), width: 240, height: 240, correctLevel: QRCode.CorrectLevel.M });
      setTimeout(function () {
        var c = box.querySelector('canvas');
        if (!c) { box.remove(); alert('لم يجهز الباركود بعد، أعد المحاولة.'); return; }
        var out = document.createElement('canvas'); out.width = 320; out.height = 372;
        var x = out.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, 320, 372);
        x.drawImage(c, 40, 24, 240, 240);
        x.fillStyle = '#dc143c'; x.font = '800 20px sans-serif'; x.textAlign = 'center'; x.fillText('Sprich', 160, 298);
        x.fillStyle = '#555'; x.font = '600 14px sans-serif'; x.fillText(mins + ' min · ' + data.date.slice(0, 10), 160, 326);
        var url = out.toDataURL('image/png'); box.remove();
        var r = modal('spQr', '<h3><i class="fas fa-qrcode"></i> باركود جلستك</h3><div style="text-align:center"><img id="spQrImg" alt="QR" style="width:220px;max-width:100%;border-radius:16px;border:1px solid #eee"></div>' +
          '<p class="sp-sub" id="spQrMsg" style="margin:12px 0"></p><div class="sp-row"><a class="sp-btn" id="spQrDl" download="sprich-session.png" style="text-decoration:none"><i class="fas fa-download"></i> تحميل الصورة</a></div>');
        $('spQrImg').src = url; $('spQrDl').href = url; $('spQrDl').setAttribute('download', 'sprich_session_' + data.sessionId + '.png');
        $('spQrMsg').textContent = 'جلسة ' + mins + ' دقيقة. احفظ الصورة ثم ارفعها في صفحة «إنجازاتي». بدأت جلسة جديدة من الصفر.';
        sess = 0; save(); paintTimer();
        $('spTimer').classList.remove('on'); r.el.classList.add('on');
      }, 120);
    });
  }

  /* ================= كشكولي: كلمات وجمل محفوظة على جهازك ================= */
  var NOTES = JSON.parse(LS.get('spNotes') || 'null') || { v: [], s: [] };
  var tab = 'v';
  function saveNotes() { LS.set('spNotes', JSON.stringify(NOTES)); }
  function confetti() {
    function go() { try { window.confetti({ particleCount: 140, spread: 70, origin: { y: .3 }, zIndex: 200000, colors: ['#dc143c', '#ff7a45', '#ffb703', '#111'] }); } catch (e) {} }
    if (window.confetti) return go();
    var s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js'; s.onload = go; document.head.appendChild(s);
  }
  function paintNotes() {
    var box = $('spNotesBody'); if (!box) return;
    var list = tab === 'v' ? NOTES.v : NOTES.s;
    var form = tab === 'v'
      ? '<input id="nA" dir="ltr" placeholder="الكلمة بالألمانية (مثال: der Kaffee)" autocomplete="off"><input id="nB" placeholder="المعنى بالعربية" autocomplete="off"><input id="nC" dir="ltr" placeholder="مثال بجملة (اختياري)" autocomplete="off">'
      : '<input id="nA" dir="ltr" placeholder="الجملة بالألمانية" autocomplete="off"><input id="nB" placeholder="الترجمة بالعربية" autocomplete="off">';
    box.innerHTML = '<div class="sp-count"><div><b>' + NOTES.v.length + '</b>كلمة</div><div><b>' + NOTES.s.length + '</b>جملة</div></div>' +
      '<div class="sp-tabs"><button type="button" data-t="v" class="' + (tab === 'v' ? 'on' : '') + '">الكلمات</button><button type="button" data-t="s" class="' + (tab === 's' ? 'on' : '') + '">الجمل</button></div>' +
      '<div class="sp-add">' + form + '<button type="button" class="sp-btn" id="nAdd"><i class="fas fa-plus"></i> إضافة</button></div>' +
      '<div class="sp-list">' + (list.length ? list.map(function (x, i) {
        return '<div class="sp-item"><div class="grow"><b>' + esc(x.a) + '</b><span>' + esc(x.b) + '</span>' + (x.c ? '<small>' + esc(x.c) + '</small>' : '') + '</div><button type="button" data-d="' + i + '" aria-label="حذف"><i class="fas fa-trash"></i></button></div>';
      }).reverse().join('') : '<div class="sp-empty">لا شيء هنا بعد — دوّن أول ' + (tab === 'v' ? 'كلمة' : 'جملة') + '.</div>') + '</div>' +
      '<div class="sp-row"><button type="button" class="sp-btn alt" id="nCopy"><i class="fas fa-copy"></i> نسخ الكل</button><button type="button" class="sp-btn" id="nPrint"><i class="fas fa-file-pdf"></i> طباعة / حفظ PDF</button></div>';
    box.querySelectorAll('[data-t]').forEach(function (b) { b.addEventListener('click', function () { tab = b.getAttribute('data-t'); paintNotes(); }); });
    box.querySelectorAll('[data-d]').forEach(function (b) { b.addEventListener('click', function () { list.splice(+b.getAttribute('data-d'), 1); saveNotes(); paintNotes(); }); });
    $('nAdd').addEventListener('click', function () {
      var a = $('nA').value.trim(), b2 = $('nB').value.trim(), c = $('nC') ? $('nC').value.trim() : '';
      if (!a) { $('nA').focus(); return; }
      list.push({ a: a, b: b2, c: c }); saveNotes(); paintNotes();
      if ((NOTES.v.length + NOTES.s.length) % 5 === 0) confetti();
    });
    function text() {
      return 'كلمات\n' + NOTES.v.map(function (x) { return x.a + ' = ' + x.b + (x.c ? '  (' + x.c + ')' : ''); }).join('\n') + '\n\nجمل\n' + NOTES.s.map(function (x) { return x.a + ' = ' + x.b; }).join('\n');
    }
    $('nCopy').addEventListener('click', function () { try { navigator.clipboard.writeText(text()); this.innerHTML = '<i class="fas fa-check"></i> تم النسخ'; } catch (e) {} });
    $('nPrint').addEventListener('click', printNotes);
  }
  /* ===== طباعة الكشكول كجدول منظّم (ومنها «حفظ بصيغة PDF» من نافذة الطباعة) ===== */
  function printNotes() {
    if (!NOTES.v.length && !NOTES.s.length) { alert('الكشكول فاضي — دوّن كلمة أو جملة أولًا.'); return; }
    var old = $('spPrint'); if (old) old.remove();
    function rows(list, third) {
      return list.map(function (x, i) {
        return '<tr><td class="n">' + (i + 1) + '</td><td class="de" dir="ltr">' + esc(x.a) + '</td><td class="ar">' + esc(x.b) + '</td>' + (third ? '<td class="ex" dir="ltr">' + esc(x.c || '') + '</td>' : '') + '</tr>';
      }).join('');
    }
    var d = new Date(), ds = d.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });
    var h = '<div class="pr-head"><div class="pr-logo">SPRICH<b>.</b></div><div class="pr-title">كشكولي — كلماتي وجملي</div><div class="pr-date">' + ds + '</div></div>';
    if (NOTES.v.length) h += '<h3>الكلمات (' + NOTES.v.length + ')</h3><table class="pr-t"><thead><tr><th class="n">#</th><th>الكلمة بالألمانية</th><th>المعنى بالعربية</th><th>مثال</th></tr></thead><tbody>' + rows(NOTES.v, true) + '</tbody></table>';
    if (NOTES.s.length) h += '<h3>الجمل (' + NOTES.s.length + ')</h3><table class="pr-t"><thead><tr><th class="n">#</th><th>الجملة بالألمانية</th><th>الترجمة بالعربية</th></tr></thead><tbody>' + rows(NOTES.s, false) + '</tbody></table>';
    h += '<div class="pr-foot">Sprich · ' + esc(location.host) + '</div>';
    var box = document.createElement('div'); box.id = 'spPrint'; box.setAttribute('dir', 'rtl'); box.innerHTML = h; document.body.appendChild(box);
    var oldTitle = document.title; document.title = 'Sprich-notes-' + d.toISOString().slice(0, 10);
    document.body.classList.add('sp-printing');
    var clean = function () { document.body.classList.remove('sp-printing'); document.title = oldTitle; var b = $('spPrint'); if (b) b.remove(); window.removeEventListener('afterprint', clean); };
    window.addEventListener('afterprint', clean);
    setTimeout(function () { window.print(); }, 150);
    setTimeout(function () { if (document.body.classList.contains('sp-printing') && !document.hidden) { /* بعض المتصفحات لا تطلق afterprint */ } }, 2000);
  }
  function openNotes() {
    var r = modal('spNotes', '<h3><i class="fas fa-pen-fancy"></i> كشكولي</h3><div id="spNotesBody"></div>');
    paintNotes(); r.el.classList.add('on');
  }
  window.openNotes = openNotes;

  /* ================= القائمة + الوضع الداكن + الأدوات ================= */
  var menu = $('sxMenu'), ov = $('sxOverlay'), btn = $('sxMenuBtn');
  if (menu) {
    var open = function () { menu.classList.add('open'); ov.classList.add('on'); menu.setAttribute('aria-hidden', 'false'); btn.setAttribute('aria-expanded', 'true'); };
    var close = function () { menu.classList.remove('open'); ov.classList.remove('on'); menu.setAttribute('aria-hidden', 'true'); btn.setAttribute('aria-expanded', 'false'); };
    btn.addEventListener('click', function () { menu.classList.contains('open') ? close() : open(); });
    $('sxMenuClose').addEventListener('click', close);
    ov.addEventListener('click', close);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
    menu.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', function () { if (a.getAttribute('href') !== '#') close(); }); });
    var path = location.pathname.replace(/\/index\.html$/, '/');
    menu.querySelectorAll('.sxm-item').forEach(function (a) {
      var h = (a.getAttribute('href') || '').split('?')[0];
      if (h === path || h === path.replace(/\.html$/, '')) a.classList.add('active');
    });
    var sx = 0, sy = 0;
    document.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; }, { passive: true });
    document.addEventListener('touchend', function (e) {
      var dx = e.changedTouches[0].clientX - sx, dy = Math.abs(e.changedTouches[0].clientY - sy);
      if (dy > 60) return;
      if (menu.classList.contains('open') && dx < -70) close();
      else if (!menu.classList.contains('open') && sx < 20 && dx > 80) open();
    }, { passive: true });

    var root = document.documentElement;
    var paintTheme = function () {
      var dark = root.getAttribute('data-theme') === 'dark';
      $('sxDarkLabel').textContent = dark ? 'الوضع الفاتح' : 'الوضع الداكن';
      $('sxDarkIcon').className = 'fas ' + (dark ? 'fa-sun' : 'fa-moon');
      var mt = document.querySelector('meta[name=theme-color]'); if (mt) mt.setAttribute('content', dark ? '#121018' : '#dc143c');
    };
    $('sxDarkTool').addEventListener('click', function () {
      var dark = root.getAttribute('data-theme') === 'dark';
      if (dark) root.removeAttribute('data-theme'); else root.setAttribute('data-theme', 'dark');
      LS.set('sprichTheme', dark ? 'light' : 'dark'); paintTheme();
    });
    paintTheme();
    $('sxTimerTool').addEventListener('click', function () { close(); openTimer(); });
    var pill = $('spPill'); if (pill) pill.addEventListener('click', function () { close(); openTimer(); });
    $('sxNotesTool').addEventListener('click', function () { close(); openNotes(); });
    $('sxFsTool').addEventListener('click', function () {
      close();
      if (!document.fullscreenElement) { if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen(); }
      else document.exitFullscreen();
    });
  }

  /* ================= PWA: التقاط حدث التثبيت (يستخدمه زر «تثبيت الآن») ================= */
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); window.__spInstall = e; document.dispatchEvent(new Event('sp-install-ready')); });
  window.addEventListener('appinstalled', function () { window.__spInstall = null; document.dispatchEvent(new Event('sp-installed')); });

  /* ================= PWA: تسجيل service worker ================= */
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    window.addEventListener('load', function () { navigator.serviceWorker.register('/sw.js').catch(function () {}); });
  }
})();
