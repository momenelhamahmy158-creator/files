/* ================================================================
   Sprich — المكتبة والبحث الذكي (يقرأ /lessons/index.json)
   صفحة المكتبة: ?cat=تصنيف أو ?level=A1   |   صفحة البحث: ?q=...
   ================================================================ */
(function () {
  'use strict';
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  /* ----- كلمات تُتجاهل: حروف الجر وأدوات الطلب والكلمات العامة ----- */
  var RAW_STOP = ('من في فى على علي الى إلى الي عن مع حتى حتي ك ل ب و ف ثم او أو ان إن أن كان كانت هل ما ماذا لماذا ليه كيف ' +
    'هذا هذه هذي ده دي دا دول ذلك تلك هو هي هم انا أنا انت أنت نحن لو لي لنا لك له لها ' +
    'عايز عايزه عايزة عايزين عاوز عاوزه عاوزة عاوزين اريد أريد ابغى ابغي ابي محتاج محتاجه محتاجة نفسي ممكن ' +
    'اعرض اعرضلي هات هاتلي وريني ورني ابحث دور دورلي لقيلي شوف اتعلم اتعلمه تعلم تعلمني علمني ' +
    'محادثه محادثة محادثات حوار حوارات درس دروس موضوع مستوى مستوي بتاع بتاعه بتاعة خاص خاصه خاصة ' +
    'بخصوص بشان بشأن حول عند بين تحت فوق قبل بعد امام أمام خلف داخل خارج منذ خلال عبر ضد نحو مثل غير سوى ' +
    'عشان علشان لان لأن اللي الذي التي اي أي ايه إيه فيه فيها بدون بس كمان كده كدا').split(' ');

  /* ----- توحيد الحروف: همزات، ياء/ألف مقصورة، تاء مربوطة، التشكيل، الأرقام ----- */
  function norm(s) {
    return String(s || '').toLowerCase()
      .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
      .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
      .replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/ء/g, '')
      .replace(/ä/g, 'a').replace(/ö/g, 'o').replace(/ü/g, 'u').replace(/ß/g, 'ss')
      .replace(/[\u0660-\u0669]/g, function (d) { return d.charCodeAt(0) - 1632; })
      .replace(/[^\u0600-\u06FFa-z0-9\s]/g, ' ');
  }
  var STOP = {};
  RAW_STOP.forEach(function (w) { STOP[norm(w)] = 1; });
  function stripAl(w) { return w.replace(/^(وال|بال|كال|فال|لل|ال)(?=.{2,})/, ''); }
  /* مفتاح الكلمة: بدون ال، بدون حروف العلة (ا و ي) وبدون لاحقة الجمع */
  function key(w) {
    w = stripAl(w);
    if (/[\u0600-\u06FF]/.test(w)) {
      if (w.length > 4) w = w.replace(/(ات|ون|ين|ان)$/, '');
      var s = w.replace(/[اوي]/g, '');
      return s.length >= 2 ? s : w;
    }
    return w;
  }
  function tokens(q) {
    var out = [];
    norm(q).split(/\s+/).forEach(function (w) {
      if (!w || STOP[w]) return;
      var b = stripAl(w);
      if (STOP[b] || b.length < 2) return;
      var k = key(w);
      if (out.indexOf(k) < 0) out.push(k);
    });
    return out;
  }
  /* فرق حرف واحد على الأكثر (يسامح الأخطاء الإملائية) */
  function near(a, b) {
    if (Math.abs(a.length - b.length) > 1) return false;
    var i = 0, j = 0, d = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) { i++; j++; continue; }
      if (++d > 1) return false;
      if (a.length > b.length) i++; else if (a.length < b.length) j++; else { i++; j++; }
    }
    return d + (a.length - i) + (b.length - j) <= 1;
  }
  function sim(q, d) {
    if (q === d) return 1;
    var m = Math.min(q.length, d.length);
    if (m >= 3 && (d.indexOf(q) > -1 || q.indexOf(d) > -1)) return 0.85;
    if (m >= 4 && near(q, d)) return 0.6;
    return 0;
  }
  function prep(e) {
    e.tk = tokens(e.title);
    e.lk = [];
    (e.cats || []).forEach(function (l) { e.lk = e.lk.concat(tokens(l)); });
    return e;
  }
  function search(list, q) {
    var qt = tokens(q);
    if (!qt.length) return list.slice();
    var res = [];
    list.forEach(function (e) {
      var hit = 0, score = 0;
      qt.forEach(function (t) {
        var best = 0;
        e.tk.forEach(function (d) { var s = sim(t, d) * 3; if (s > best) best = s; });
        e.lk.forEach(function (d) { var s = sim(t, d) * 2; if (s > best) best = s; });
        if (best > 0) { hit++; score += best; }
      });
      if (hit > 0) res.push({ e: e, hit: hit, score: score });
    });
    res.sort(function (a, b) { return b.hit - a.hit || b.score - a.score || (b.e.time || 0) - (a.e.time || 0); });
    return res.map(function (r) { return r.e; });
  }

  function load() {
    return fetch('/lessons/index.json', { cache: 'no-cache' }).then(function (r) { return r.json(); })
      .then(function (j) { return (j.lessons || j || []).map(prep); }).catch(function () { return null; });
  }
  function card(e) {
    var tags = (e.cats || []).map(function (l) { return '<span>' + esc(l) + '</span>'; }).join('');
    return '<a class="lc" href="/lesson.html?l=' + encodeURIComponent(e.slug) + '"><span class="lc-art" aria-hidden="true"><i class="s1"></i><i class="s2"></i><i class="s3"></i></span>' +
      '<div class="lc-row">' + (e.level ? '<span class="lc-level">' + esc(e.level) + '</span>' : '') + '<span class="lc-arrow"><i class="fas fa-arrow-left"></i></span></div>' +
      '<div class="lc-bottom"><h3 class="lc-title">' + esc(e.title) + '</h3><div class="lc-steps">' + tags + '</div></div></a>';
  }
  function grid(list, empty) {
    return list.length ? '<div class="lc-grid">' + list.map(card).join('') + '</div>' : '<p class="sx-empty">' + empty + '</p>';
  }
  var P = new URLSearchParams(location.search);

  /* ================= صفحة المكتبة ================= */
  if ($('spLibrary')) {
    var cat = (P.get('cat') || '').trim(), level = (P.get('level') || '').trim().toUpperCase();
    load().then(function (list) {
      var head = $('spHead'), out = $('spResults');
      if (!list) { out.innerHTML = '<p class="sx-empty">تعذّر تحميل الدروس. تحقّق من الاتصال وأعد المحاولة.</p>'; return; }
      var shown = list;
      if (cat) shown = shown.filter(function (e) { return (e.cats || []).indexOf(cat) > -1; });
      if (level) shown = shown.filter(function (e) { return (e.level || '').toUpperCase() === level; });
      head.innerHTML = cat ? '<h1 class="sx-cat"><i class="fas fa-layer-group"></i> ' + esc(cat) + '</h1>' :
        level ? '<span class="k"><i class="fas fa-signal"></i> المستوى</span><h1>' + esc(level) + '</h1>' :
        '<span class="k"><i class="fas fa-book-open"></i> المكتبة</span><h1>كل المحادثات</h1>';
      document.title = (cat || (level ? 'المستوى ' + level : 'كل المحادثات')) + ' | Sprich';
      /* فلاتر: المستويات ثم التصنيفات */
      var lv = ['A1', 'A2', 'B1', 'B2', 'C1'], cats = [];
      list.forEach(function (e) { (e.cats || []).forEach(function (c) { if (cats.indexOf(c) < 0) cats.push(c); }); });
      var f = '<a href="/lessons.html" class="' + (!cat && !level ? 'on' : '') + '">الكل</a>';
      lv.forEach(function (l) { f += '<a href="/lessons.html?level=' + l + '" class="' + (level === l ? 'on' : '') + '">' + l + '</a>'; });
      if (cats.length) f += '<span class="sep"></span>';
      cats.forEach(function (c) { f += '<a href="/lessons.html?cat=' + encodeURIComponent(c) + '" class="' + (cat === c ? 'on' : '') + '">' + esc(c) + '</a>'; });
      $('spFilters').innerHTML = f;
      out.innerHTML = grid(shown, 'لا توجد دروس هنا بعد — سيتم إضافتها قريبًا.');
    });
  }

  /* ================= صفحة نتائج البحث ================= */
  if ($('spSearch')) {
    var q = (P.get('q') || '').trim();
    if ($('spQ')) $('spQ').textContent = '«' + q + '»';
    if ($('spInput')) $('spInput').value = q;
    document.title = 'نتائج البحث عن: ' + q + ' | Sprich';
    load().then(function (list) {
      var out = $('spResults'), st = $('spStatus');
      if (!list) { out.innerHTML = '<p class="sx-empty">تعذّر تحميل الدروس. تحقّق من الاتصال وأعد المحاولة.</p>'; return; }
      var r = q ? search(list, q) : list;
      out.innerHTML = grid(r, 'لا توجد دروس مطابقة لبحثك — جرّب كلمات أخرى.');
      if (r.length && st) { st.hidden = false; st.innerHTML = 'تم العثور على <b>' + r.length + '</b> درس'; }
    });
  }
})();
