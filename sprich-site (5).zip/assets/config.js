/* ================================================================
   🔗 روابط المنصة — عدّل الروابط من هنا فقط
   (تتغيّر تلقائياً في الصفحة الرئيسية وفي القائمة)
   اترك '#' للرابط الذي لم تجهّزه بعد.
   ================================================================ */
window.SX_LINKS = {
  explain:      '/explain.html',              /* شرح المنصة */
  placement:    '/placement.html',            /* تحديد المستوى */
  A1: '/lessons.html?level=A1',               /* روابط المستويات */
  A2: '/lessons.html?level=A2',
  B1: '/lessons.html?level=B1',
  B2: '/lessons.html?level=B2',
  C1: '/lessons.html?level=C1',
  achievements: '/achievements.html',         /* إنجازاتي */
  shadowing:    '/shadowing.html',            /* تدريب Shadowing */
  library:      '/lessons.html',              /* مكتبة المصادر */
  install:      '/install.html',              /* تحميل التطبيق */
  about:        '/about.html',
  contact:      '/contact.html',
  privacy:      '/privacy.html',
  terms:        '/terms.html'
};

/* ================================================================
   📲 روابط تحميل التطبيق (صفحة install.html)
   ضع الرابط الحقيقي بدل '#' بعد تجهيز كل نسخة.
   ================================================================ */
window.SX_DOWNLOADS = {
  android:   '/downloads/sprich.apk',   /* ملف APK مباشر */
  playstore: '#',   /* رابط Google Play بعد النشر */
  ios:       '#',   /* رابط App Store أو TestFlight إن وُجد (وإلا يعمل التثبيت من Safari) */
  windows:   'https://apps.microsoft.com/detail/9pgfh861cd7z?hl=en-US&gl=EG'   /* Microsoft Store */
};

/* ================================================================
   ✉️ نموذج «اتصل بنا»
   النموذج يرسل الرسائل إلى بريدك عبر خدمة FormSubmit المجانية.
   لازم تضغط «Activate Form» في بريد FormSubmit مرة واحدة فقط لتبدأ الرسائل بالوصول.
   ================================================================ */
window.SX_CONTACT = {
  email: 'momenelhamahmy158@gmail.com',
  endpoint: 'https://formsubmit.co/ajax/310cf40eb7a5bc67db82cd2e3b0dd26e'   /* الرمز العشوائي بدل البريد الظاهر */
};
