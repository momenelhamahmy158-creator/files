/* ================================================================
   Sprich — صوت ألماني مشترك (نفس صوت الدروس) للصفحات خارج محرك الدرس
   يستخدم أصوات Piper المحفوظة في جهازك، وإن لم تجهز يعمل صوت المتصفح الألماني.
   الاستخدام:
     SprichTTS.init(function(progress0to1){})   // يحمّل الأصوات (مرة واحدة) → Promise<boolean>
     SprichTTS.speak('Guten Tag', {spk:0, speed:1, onStart:function(ms){}}) → Promise<boolean>
     SprichTTS.stop(); SprichTTS.prefetch(text, spk); SprichTTS.ready()
   ================================================================ */
(function () {
  'use strict';
  var LS = { get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } } };
  var VOICES = (window.LXP && window.LXP.VOICES) || ['de_DE-thorsten-medium', 'de_DE-karlsson-low'];
  function voiceId(spk) { return VOICES[spk === 1 ? 1 : 0]; }
  function pitchOf(spk) { return spk === 1 ? 1.2 : 1.04; }
  function enabled() { return true; }
  var S = { state: 'idle', tts: null, cache: {}, f: {}, lock: Promise.resolve(), pa: new Audio(), tok: 0, pend: null, unlocked: false };
  document.addEventListener('click', function () {
    if (S.unlocked) return; S.unlocked = true;
    try { S.pa.src = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA='; var p = S.pa.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
  }, true);

  /* ----- ذاكرة دائمة مشتركة مع محرك الدروس (IndexedDB) ----- */
  var IDBP = null;
  function idb() {
    if (!IDBP) {
      IDBP = new Promise(function (res, rej) {
        try { var r = indexedDB.open('lx-audio', 1); r.onupgradeneeded = function () { r.result.createObjectStore('w'); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; } catch (e) { rej(e); }
      });
      IDBP.catch(function () {});
    }
    return IDBP;
  }
  function idbGet(k) { return idb().then(function (db) { return new Promise(function (res) { var q = db.transaction('w').objectStore('w').get(k); q.onsuccess = function () { res(q.result || null); }; q.onerror = function () { res(null); }; }); }).catch(function () { return null; }); }
  function idbPut(k, rec) {
    return idb().then(function (db) {
      return new Promise(function (res) {
        var tx = db.transaction('w', 'readwrite'), os = tx.objectStore('w'); os.put(rec, k);
        var c = os.count(); c.onsuccess = function () { if (c.result > 400) os.clear(); };
        tx.oncomplete = res; tx.onerror = res;
      });
    }).catch(function () {});
  }
  /* طبقة الصوت تُخبَّز داخل ملف WAV فلا تتأثر بسرعة التشغيل */
  function retune(blob, f) {
    if (!f || Math.abs(f - 1) < 0.01) return Promise.resolve(blob);
    return blob.arrayBuffer().then(function (buf) {
      var v = new DataView(buf), i = 12;
      if (buf.byteLength < 44 || v.getUint32(0) !== 0x52494646) return blob;
      while (i + 8 <= buf.byteLength) {
        var id = v.getUint32(i), sz = v.getUint32(i + 4, true);
        if (id === 0x666d7420) {
          var sr = v.getUint32(i + 12, true), ba = v.getUint16(i + 20, true), nsr = Math.round(sr * f);
          v.setUint32(i + 12, nsr, true); v.setUint32(i + 16, nsr * ba, true);
          var nb = new Blob([buf], { type: 'audio/wav' }); nb.__f = f; return nb;
        }
        i += 8 + sz + (sz % 2);
      }
      return blob;
    });
  }
  function pSynth(text, spk) {
    var key = voiceId(spk) + '|' + text;
    if (S.cache[key]) return S.cache[key];
    var m = S.tts, vid = voiceId(spk), f = pitchOf(spk), dk = 'v1|' + vid + '|' + f + '|' + text;
    var p = idbGet(dk).then(function (rec) {
      if (rec && rec.buf) return { blob: new Blob([rec.buf], { type: 'audio/wav' }), f: rec.f || 1 };
      var run = S.lock.then(function () { return m.predict({ text: text, voiceId: vid }); }).then(function (b) { return retune(b, f); });
      S.lock = run.catch(function () {});
      return run.then(function (b) { var o = { blob: b, f: b.__f || 1 }; b.arrayBuffer().then(function (buf) { idbPut(dk, { buf: buf, f: o.f }); }); return o; });
    }).then(function (o) { var u = URL.createObjectURL(o.blob); S.f[u] = o.f; return u; });
    S.cache[key] = p; p.catch(function () { delete S.cache[key]; });
    return p;
  }

  function init(onProg) {
    if (!enabled()) return Promise.resolve(false);
    if (S.state === 'ready') return Promise.resolve(true);
    return Promise.resolve().then(function () {
      if (!window.LXP) throw new Error('LXP');
      return window.LXP.load([voiceId(0), voiceId(1)], onProg);
    }).then(function (m) { S.tts = m; S.state = 'ready'; return true; })
      .catch(function () { S.state = 'failed'; return false; });
  }
  function stop() {
    S.tok++;
    try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch (e) {}
    try { S.pa.onended = null; S.pa.onerror = null; S.pa.onplaying = null; S.pa.pause(); } catch (e) {}
    if (S.pend) { var p = S.pend; S.pend = null; p(false); }
  }
  function germanVoice(spk) {
    var vs = (window.speechSynthesis && speechSynthesis.getVoices()) || [], de = vs.filter(function (v) { return /^de/i.test(v.lang); });
    if (!de.length) return null;
    var male = de.filter(function (v) { return /male|markus|stefan|conrad|killian|florian|jonas|hans|martin/i.test(v.name) && !/female/i.test(v.name); });
    return male[0] || de[0];
  }
  function browser(text, spk, speed, fin, onStart) {
    if (onStart) { try { onStart(Math.max(900, text.length * 68 / speed)); } catch (e) {} }
    if (!window.speechSynthesis || !('SpeechSynthesisUtterance' in window)) return fin();
    var u = new SpeechSynthesisUtterance(text), v = germanVoice(spk);
    u.lang = 'de-DE'; if (v) { u.voice = v; u.lang = v.lang; }
    u.pitch = spk === 1 ? 0.5 : 0.72; u.rate = speed; u.onend = fin; u.onerror = fin; window.__spU = u;
    speechSynthesis.speak(u);
  }
  function speak(text, o) {
    o = o || {}; var spk = o.spk === 1 ? 1 : 0, speed = o.speed || 1;
    stop(); var my = ++S.tok;
    return new Promise(function (resolve) {
      S.pend = resolve;
      var fin = function () { if (my !== S.tok) return; S.pend = null; resolve(true); };
      setTimeout(function () {
        if (my !== S.tok) return;
        if (S.state === 'ready' && enabled()) {
          pSynth(text, spk).then(function (url) {
            if (my !== S.tok) return;
            var started = false, pa = S.pa, rate = Math.max(0.5, speed / (S.f[url] || 1));
            pa.onended = fin; pa.onerror = fin;
            pa.onplaying = function () { if (started || my !== S.tok) return; started = true; if (o.onStart) { try { o.onStart(pa.duration * 1000 / pa.playbackRate); } catch (e) {} } };
            pa.src = url; pa.defaultPlaybackRate = rate; pa.playbackRate = rate;
            try { pa.preservesPitch = true; pa.mozPreservesPitch = true; pa.webkitPreservesPitch = true; } catch (e) {}
            var pl = pa.play(); if (pl && pl.catch) pl.catch(function () { if (my === S.tok && !started) browser(text, spk, speed, fin, o.onStart); });
          }, function () { if (my === S.tok) browser(text, spk, speed, fin, o.onStart); });
        } else browser(text, spk, speed, fin, o.onStart);
      }, 30);
    });
  }
  window.SprichTTS = {
    init: init, speak: speak, stop: stop,
    ready: function () { return S.state === 'ready' && enabled(); },
    prefetch: function (t, spk) { if (S.state === 'ready' && enabled()) return pSynth(t, spk === 1 ? 1 : 0).catch(function () {}); return Promise.resolve(); },
    hasBrowserVoice: function () { return !!germanVoice(0); }
  };
})();
