
/* ================================================================
   محرّك درس المحادثة (تصميم الواتساب) — يقرأ window.convData فقط
   كل سطر: { name, side?, de, ar?, words?:[{de, art, ar}] }
   المراحل: استمع ← Shadowing ← البطاقات ← دورك (بالصوت / كتابةً)
   ================================================================ */
(function () {
  'use strict';
  var DATA = window.convData;
  if (!Array.isArray(DATA) || !DATA.length || window.__convLoaded) return;
  window.__convLoaded = true;

  /* ---------- أدوات ---------- */
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var _dt = document.createElement('textarea');
  function dec(s) { s = String(s == null ? '' : s); if (s.indexOf('&') < 0) return s; _dt.innerHTML = s; return _dt.value; }
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return [].slice.call((r || document).querySelectorAll(s)); }
  function ce(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  /* ---------- تجهيز البيانات ---------- */
  var names = [];
  var L = DATA.map(function (d, i) {
    var n = dec(d.name || ('Sprecher ' + (i % 2 + 1)));
    if (names.indexOf(n) < 0) names.push(n);
    return { name: n, spk: 0, side: d.side, de: dec(d.de || d.text || d.en || '').trim(), ar: d.ar ? dec(d.ar).trim() : '', words: d.words || [] };
  }).filter(function (l) { return l.de; });
  if (!L.length) return;
  L.forEach(function (l) { l.spk = names.indexOf(l.name) % 2; if (l.side !== 'left' && l.side !== 'right') l.side = l.spk === 0 ? 'right' : 'left'; });
  var WORDS = [], seen = {};
  function wTxt(w) { return (w.art ? w.art + ' ' : '') + w.de; }
  function addW(w, ex) {
    if (!w || !w.de) return;
    var k = dec(w.de).toLowerCase(); if (seen[k]) return; seen[k] = 1;
    if (!ex) { L.some(function (l) { if (l.de.toLowerCase().indexOf(k) > -1) { ex = l.de; return true; } }); }
    WORDS.push({ de: dec(w.de), art: dec(w.art || ''), ar: dec(w.ar || ''), ex: dec(w.ex || ex || '') });
  }
  (window.convWords || []).forEach(function (w) { addW(w); });
  L.forEach(function (l) { l.words.forEach(function (w) { addW(w, l.de); }); });
  var PREPS = L.map(function (l) { return { t: l.de, s: l.spk }; }).concat(WORDS.map(function (w) { return { t: wTxt(w), s: 0 }; }));

  /* ================= الصوت: ألماني + حدّة صوت مختلفة لكل شخص ================= */
  var synth = window.speechSynthesis, deVoices = [], speed = 1, loops = 1, tok = 0, curAudio = null, pend = null;
  /* نبرات معتدلة (بدون حدّة): أنثى أعلى قليلاً، ذكر أوطأ قليلاً */
  var VOICE = { 0: { pitch: 0.72, rate: 1.0, ap: 0.9 }, 1: { pitch: 0.5, rate: 0.95, ap: 0.8 } };
  function rank(v) { return (/natural|neural|online/i.test(v.name) ? 4 : 0) + (/google|premium|enhanced/i.test(v.name) ? 2 : 0) + (v.localService ? 0 : 1); }
  var FEM = /anna|petra|marlene|vicki|hedda|katja|helena|marie|sabine|female|frau|amala|seraphina|elke|google deutsch/i;
  var MAL = /stefan|markus|hans|conrad|klaus|killian|jonas|florian|male|mann|bernd|yannick|christoph|jan\b/i;
  function loadVoices() {
    if (!synth) return;
    deVoices = synth.getVoices().filter(function (v) { return /^de[-_]/i.test(v.lang) || /german|deutsch/i.test(v.name); }).sort(function (a, b) { return rank(b) - rank(a); });
  }
  if (synth) { loadVoices(); if (synth.onvoiceschanged !== undefined) synth.onvoiceschanged = loadVoices; }
  function voiceFor(spk) {
    if (!deVoices.length) return null;
    var m = deVoices.filter(function (v) { return MAL.test(v.name) && !/female/i.test(v.name); });
    if (m.length) return m[spk === 1 && m.length > 1 ? 1 : 0];
    return deVoices[spk === 1 && deVoices.length > 1 ? 1 : 0];
  }
  /* ================= Piper: أصوات رجلين ألمانيين تعمل داخل المتصفح (بدون رفع ملفات) ================= */
  var LS = { get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };
  /* صوتان ذكوريان مختلفان. يمكن تغييرهما لكل محادثة: window.convVoices = ['de_DE-thorsten-medium', 'de_DE-pavoque-low'] */
  var VOICES = ['de_DE-thorsten-medium', 'de_DE-karlsson-low'];
  var conn = navigator.connection || {};
  var PIPER = { on: true, state: 'idle', tts: null, cache: {}, f: {}, lock: Promise.resolve(), gen: 0, bg: 0, skip: false, busy: false };
  var pa = new Audio(), paUnlocked = false;
  document.addEventListener('click', function () {
    if (paUnlocked) return; paUnlocked = true;
    try { pa.src = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA='; var p = pa.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
  }, true);
  function voiceId(spk) {
    var v = (Array.isArray(window.convVoices) && window.convVoices.length > 1) ? window.convVoices : VOICES;
    return v[spk === 1 ? 1 : 0];
  }
  function chip(txt, ok) {
    var c = document.getElementById('lx-vchip'); if (!c) return;
    if (!txt) { c.style.display = 'none'; return; }
    c.style.display = 'block'; c.className = 'lx-vchip' + (ok ? ' ok' : ''); c.innerHTML = txt;
  }
  function ovSet(pct, txt) {
    var o = document.getElementById('lx-load'); if (!o) return;
    o.style.setProperty('--p', pct); var ring = document.getElementById('lx-ldring'); if (ring) ring.style.setProperty('--p', pct);
    var pc = document.getElementById('lx-ldpct'); if (pc) pc.textContent = txt || (pct + '%');
  }
  function ovShow() { var o = document.getElementById('lx-load'); if (o && !PIPER.skip) o.classList.add('on'); }
  function ovHide() { var o = document.getElementById('lx-load'); if (o) o.classList.remove('on'); }
  function piperInit() {
    if (!PIPER.on || PIPER.state === 'loading' || PIPER.state === 'ready') return;
    var gen = ++PIPER.gen; PIPER.state = 'loading'; PIPER.busy = true;
    var dlf = 0, lines = 0, phase = 'dl';
    /* التحميل 60% وتجهيز الأسطر 40%: شريط واحد للمحادثة كلها */
    function pct() { return Math.round((dlf * 0.6 + lines / Math.max(1, PREPS.length) * 0.4) * 100); }
    function show() {
      var p = pct(); ovSet(p);
      var sub = document.getElementById('lx-ldsub'), sm = document.getElementById('lx-ldsm');
      if (sub) sub.textContent = phase === 'dl' ? 'جاري تحميل الأصوات' : 'جاري تجهيز المحادثة…';
      if (sm) sm.style.display = phase === 'dl' ? '' : 'none';
      if (PIPER.skip) chip('<i class="fas fa-spinner fa-spin"></i> جاري تحميل المحادثة… ' + p + '%');
    }
    PIPER.show = show;
    /* لو كل شيء محفوظ ينتهي بسرعة ولا تظهر الطبقة */
    setTimeout(function () { if (gen === PIPER.gen && PIPER.busy) { ovShow(); show(); } }, 450);
    Promise.resolve().then(function () {
      if (!window.LXP) throw new Error('LXP');
      return window.LXP.load([voiceId(0), voiceId(1)], function (f) { if (gen === PIPER.gen) { dlf = f; show(); } });
    }).then(function (m) {
      if (gen !== PIPER.gen) return;
      PIPER.tts = m; PIPER.state = 'ready'; dlf = 1; phase = 'prep'; show();
      return prepLines(gen, function (n) { lines = n; show(); });
    }).then(function () {
      if (gen !== PIPER.gen) return;
      PIPER.busy = false; chip('');
      var o = document.getElementById('lx-load');
      if (o && o.classList.contains('on')) { ovSet(100, '✓'); setTimeout(ovHide, 600); }
    }).catch(function (e) {
      if (gen !== PIPER.gen) return;
      PIPER.busy = false; ovHide();
      if (PIPER.state !== 'ready') {
        PIPER.state = 'failed';
        chip('تعذّر تحميل أصوات Piper، ويعمل صوت المتصفح مؤقتًا. <button type="button" id="lx-retry" style="margin-inline-start:8px;background:#fff;color:#17141f;border-radius:10px;padding:3px 12px;font-weight:900">إعادة المحاولة</button><br><small dir="ltr">' + esc(String((e && e.message) || e).slice(0, 110)) + '</small>');
        var rb = document.getElementById('lx-retry'); if (rb) rb.onclick = function () { chip(''); PIPER.state = 'idle'; PIPER.warned = false; piperInit(); };
      } else chip('');
      try { console.warn('Piper:', e); } catch (_) {}
    });
  }
  function setPiper(v) {
    PIPER.on = v; LS.set('lx_piper', v ? '1' : '0'); PIPER.gen++; PIPER.bg++; PIPER.state = 'idle'; PIPER.skip = false; PIPER.busy = false;
    ovHide();
    if (v) piperInit(); else { stopSpeak(); chip(''); }
  }
  /* طبقة الصوت تُخبَّز داخل الملف نفسه (بتغيير معدّل العينات في رأس WAV)، فلا تتأثر بسرعة التشغيل */
  function retune(blob, f) {
    if (!f || Math.abs(f - 1) < 0.01) return Promise.resolve(blob);
    return blob.arrayBuffer().then(function (buf) {
      var v = new DataView(buf), i = 12;
      if (buf.byteLength < 44 || v.getUint32(0) !== 0x52494646) return blob;
      while (i + 8 <= buf.byteLength) {
        var id = v.getUint32(i), sz = v.getUint32(i + 4, true);
        if (id === 0x666d7420) {
          var sr = v.getUint32(i + 12, true), ba = v.getUint16(i + 20, true), nsr = Math.round(sr * f);
          v.setUint32(i + 12, nsr, true); v.setUint32(i + 16, nsr * ba, true);
          var nb = new Blob([buf], { type: 'audio/wav' }); nb.__f = f; return nb;
        }
        i += 8 + sz + (sz % 2);
      }
      return blob;
    });
  }
  /* ذاكرة دائمة للأسطر المولَّدة (IndexedDB): فتح الدرس مرة ثانية لا يعيد التوليد */
  var IDBP = null;
  function idb() {
    if (!IDBP) {
      IDBP = new Promise(function (res, rej) {
        try { var r = indexedDB.open('lx-audio', 1); r.onupgradeneeded = function () { r.result.createObjectStore('w'); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; } catch (e) { rej(e); }
      });
      IDBP.catch(function () {});
    }
    return IDBP;
  }
  function idbGet(k) {
    return idb().then(function (db) { return new Promise(function (res) { var q = db.transaction('w').objectStore('w').get(k); q.onsuccess = function () { res(q.result || null); }; q.onerror = function () { res(null); }; }); }).catch(function () { return null; });
  }
  function idbPut(k, rec) {
    return idb().then(function (db) {
      return new Promise(function (res) {
        var tx = db.transaction('w', 'readwrite'), os = tx.objectStore('w');
        os.put(rec, k);
        var c = os.count(); c.onsuccess = function () { if (c.result > 400) os.clear(); };
        tx.oncomplete = res; tx.onerror = res;
      });
    }).catch(function () {});
  }
  /* توليد الصوت (طابور واحد) + ذاكرة مؤقتة ودائمة لكل سطر */
  function pSynth(text, spk) {
    var key = voiceId(spk) + '|' + text;
    if (PIPER.cache[key]) return PIPER.cache[key];
    var m = PIPER.tts, vid = voiceId(spk), f = pitchOf(spk), dk = 'v1|' + vid + '|' + f + '|' + text;
    var p = idbGet(dk).then(function (rec) {
      if (rec && rec.buf) return { blob: new Blob([rec.buf], { type: 'audio/wav' }), f: rec.f || 1 };
      var run = PIPER.lock.then(function () { return m.predict({ text: text, voiceId: vid }); }).then(function (b) { return retune(b, f); });
      PIPER.lock = run.catch(function () {});
      return run.then(function (b) {
        var o = { blob: b, f: b.__f || 1 };
        b.arrayBuffer().then(function (buf) { idbPut(dk, { buf: buf, f: o.f }); });
        return o;
      });
    }).then(function (o) { var u = URL.createObjectURL(o.blob); PIPER.f[u] = o.f; return u; });
    PIPER.cache[key] = p;
    p.catch(function () { delete PIPER.cache[key]; });
    return p;
  }
  /* تجهيز كل الأسطر ضمن طبقة التحميل (مع إفساح الوقت للرسم بين سطر وآخر) */
  async function prepLines(gen, cb) {
    for (var i = 0; i < PREPS.length; i++) {
      if (gen !== PIPER.gen) return;
      try { await pSynth(PREPS[i].t, PREPS[i].s); } catch (e) {}
      cb(i + 1);
      await new Promise(function (r) { setTimeout(r, 20); });
    }
  }
  function pre(i) { if (L[i] && PIPER.on && PIPER.state === 'ready') { try { pSynth(L[i].de, L[i].spk).catch(function () {}); } catch (e) {} } }

  function stopSpeak() {
    tok++;
    if (synth) { try { synth.cancel(); } catch (e) {} }
    if (curAudio) { try { curAudio.pause(); } catch (e) {} curAudio = null; }
    try { pa.onended = null; pa.onerror = null; pa.onplaying = null; pa.pause(); } catch (e) {}
    if (pend) { var p = pend; pend = null; p(false); }
  }
  /* الاحتياطي: صوت المتصفح ثم Google */
  function synthFail(e) {
    if (PIPER.warned) return; PIPER.warned = true;
    chip('تعذّر توليد صوت Piper على جهازك، ويعمل صوت المتصفح. <br><small dir="ltr">' + esc(String((e && e.message) || e).slice(0, 110)) + '</small>');
  }
  function browserSpeak(text, spk, fin, onStart) {
    if (onStart) { try { onStart(Math.max(900, text.length * 68 / speed)); } catch (e) {} }
    if (synth && 'SpeechSynthesisUtterance' in window) {
      var u = new SpeechSynthesisUtterance(text), v = voiceFor(spk);
      u.lang = 'de-DE'; if (v) { u.voice = v; u.lang = v.lang; }
      u.pitch = VOICE[spk].pitch; u.rate = VOICE[spk].rate * speed;
      u.onend = fin; u.onerror = fin; window.__convU = u;
      synth.speak(u);
    } else {
      var a = new Audio('https://translate.google.com/translate_tts?ie=UTF-8&q=' + encodeURIComponent(text) + '&tl=de&client=tw-ob');
      a.preservesPitch = false; a.mozPreservesPitch = false; a.webkitPreservesPitch = false;
      a.playbackRate = VOICE[spk].ap * speed; a.onended = fin; a.onerror = fin; curAudio = a;
      var pl = a.play(); if (pl && pl.catch) pl.catch(fin);
    }
  }
  /* طبقة صوت كل شخص (1 = الصوت الأصلي): الأول أخف قليلًا والثاني أحدّ بوضوح. يمكن تغييرها: window.convPitch = [1.04, 1.2] */
  function pitchOf(spk) { var p = Array.isArray(window.convPitch) ? +window.convPitch[spk] : 0; return (p > 0.5 && p < 2) ? p : (spk === 1 ? 1.2 : 1.04); }
  /* تجهيز كل أسطر الدرس قبل التشغيل حتى لا يحدث توليد أثناء العرض (يسبب تقطيعًا وتأخر الصورة) */
  async function prepAll(run, prog) {
    for (var i = 0; i < L.length; i++) {
      if (run !== runId) return;
      if (prog) prog(i + 1);
      try { await pSynth(L[i].de, L[i].spk); } catch (e) {}
    }
  }
  /* يرجع Promise: true عند انتهاء النطق، false لو أُلغي. onStart(مدة_بالمللي) يُستدعى لحظة بدء الصوت فعلًا */
  function speakP(text, spk, onStart) {
    stopSpeak(); spk = spk === 1 ? 1 : 0;
    return new Promise(function (resolve) {
      var my = tok, finished = false;
      pend = resolve;
      var fin = function () { if (finished || my !== tok) return; finished = true; pend = null; resolve(true); };
      setTimeout(function () {
        if (my !== tok) return;
        if (PIPER.on && PIPER.state === 'ready') {
          pSynth(text, spk).then(function (url) {
            if (my !== tok) return;
            var started = false, rate = Math.max(0.5, speed / (PIPER.f[url] || 1));
            pa.onended = fin; pa.onerror = fin;
            pa.onplaying = function () { if (started || my !== tok) return; started = true; if (onStart) { try { onStart(pa.duration * 1000 / pa.playbackRate); } catch (e) {} } };
            pa.src = url;
            pa.defaultPlaybackRate = rate; pa.playbackRate = rate;
            try { pa.preservesPitch = true; pa.mozPreservesPitch = true; pa.webkitPreservesPitch = true; } catch (e) {}
            var pl = pa.play();
            if (pl && pl.catch) pl.catch(function () { if (my === tok && !started) browserSpeak(text, spk, fin, onStart); });
          }, function (e) { synthFail(e); if (my === tok) browserSpeak(text, spk, fin, onStart); });
        } else browserSpeak(text, spk, fin, onStart);
      }, 40);
    });
  }
  function say(text, spk) { speakP(text, spk); }

  /*PURE-START*/
  /* ================= تحليل النص ونسبة المطابقة ================= */
  function nrm(s) {
    s = String(s).toLowerCase().replace(/ß/g, 'ss');
    try { s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) {}
    return s.replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function lev(a, b) {
    var m = a.length, n = b.length, d = [], i, j;
    for (i = 0; i <= m; i++) d[i] = [i];
    for (j = 1; j <= n; j++) d[0][j] = j;
    for (i = 1; i <= m; i++) for (j = 1; j <= n; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return d[m][n];
  }
  function wsim(a, b) { if (a === b) return 1; var m = Math.max(a.length, b.length); return m ? 1 - lev(a, b) / m : 0; }
  function toks(s) { return String(s).split(/\s+/).map(function (w) { return { o: w, n: nrm(w) }; }).filter(function (t) { return t.n; }); }
  function compare(exp, heard) {
    var E = toks(exp), H = toks(heard), n = E.length, m = H.length, i, j, dp = [];
    for (i = 0; i <= n; i++) { dp[i] = []; for (j = 0; j <= m; j++) dp[i][j] = 0; }
    function sim(a, b) { var s = wsim(E[a].n, H[b].n); return s >= 0.6 ? s : 0; }
    for (i = 1; i <= n; i++) for (j = 1; j <= m; j++) {
      var s = sim(i - 1, j - 1), v = Math.max(dp[i - 1][j], dp[i][j - 1]);
      if (s > 0) v = Math.max(v, dp[i - 1][j - 1] + s);
      dp[i][j] = v;
    }
    var es = [], hs = [];
    for (i = 0; i < n; i++) es[i] = 0;
    for (j = 0; j < m; j++) hs[j] = 0;
    i = n; j = m;
    while (i > 0 && j > 0) {
      var s2 = sim(i - 1, j - 1);
      if (s2 > 0 && dp[i][j] === dp[i - 1][j - 1] + s2) { es[i - 1] = s2; hs[j - 1] = s2; i--; j--; }
      else if (dp[i - 1][j] >= dp[i][j - 1]) i--; else j--;
    }
    var sum = 0, extra = 0;
    es.forEach(function (x) { sum += x; });
    hs.forEach(function (x) { if (!x) extra++; });
    var pct = n ? Math.round(100 * sum / (n + extra * 0.4)) : 0;
    pct = Math.max(0, Math.min(100, pct));
    return {
      pct: pct,
      E: E.map(function (t, k) { return { w: t.o, c: es[k] >= 0.85 ? 'ok' : es[k] > 0 ? 'near' : 'miss' }; }),
      H: H.map(function (t, k) { return { w: t.o, c: hs[k] >= 0.85 ? 'ok' : hs[k] > 0 ? 'near' : 'extra' }; })
    };
  }
  /* خطة تمرين الكتابة: حذف كلمة (أو كلمتين) أو الجملة كاملة */
  var FWD = /^(der|die|das|ein|eine|einen|einem|und|ich|du|er|sie|es|wir|ihr|ist|bin|bist|sind|ja|nein|nicht|mit|zu|von|im|in|auf|am|an|den|dem|des|mein|dein|auch|wie|was|wo|wer|wann|hast|habe|hat)$/;
  function plan(text, k) {
    var T = text.split(/\s+/), W = T.map(function (o, idx) {
      return { o: o, idx: idx, core: o.replace(/^[^A-Za-z\u00C4\u00D6\u00DC\u00E4\u00F6\u00FC\u00DF0-9]+|[^A-Za-z\u00C4\u00D6\u00DC\u00E4\u00F6\u00FC\u00DF0-9]+$/g, '') };
    });
    if (T.length <= 3 || k % 2 === 1) return { full: true, tokens: W };
    var cands = W.filter(function (w) { return w.core.length >= 3 && !FWD.test(nrm(w.core)); });
    if (!cands.length) return { full: true, tokens: W };
    var take = [cands[(k * 7 + 3) % cands.length]];
    if (T.length >= 8 && cands.length >= 3) {
      var o2 = cands[((k * 7 + 3) + Math.floor(cands.length / 2)) % cands.length];
      if (o2 !== take[0]) take.push(o2);
    }
    W.forEach(function (w) { w.blank = take.indexOf(w) > -1; });
    return { full: false, tokens: W };
  }
  /*PURE-END*/

  /* ================= التعرف على الصوت ================= */
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition, rec = null;
  function stopRec() { if (rec) { try { rec.abort(); } catch (e) {} rec = null; } }
  function listen(expected, h) {
    stopSpeak(); stopRec();
    if (!SR) { h.error('unsupported'); return; }
    var r = new SR(), got = false; rec = r;
    r.lang = 'de-DE'; r.interimResults = true; r.continuous = false; r.maxAlternatives = 3;
    r.onresult = function (e) {
      var res = e.results[e.results.length - 1];
      if (!res.isFinal) { var t = ''; for (var i = 0; i < e.results.length; i++) t += e.results[i][0].transcript + ' '; h.interim(t.trim()); return; }
      got = true;
      var best = '', bs = -1;
      for (var k = 0; k < res.length; k++) { var c = compare(expected, res[k].transcript); if (c.pct > bs) { bs = c.pct; best = res[k].transcript; } }
      h.done(best, compare(expected, best));
    };
    r.onerror = function (e) { got = true; h.error(e.error || 'error'); };
    r.onend = function () { if (rec === r) rec = null; h.end(got); };
    try { r.start(); } catch (e) { h.error('error'); }
  }
  function errMsg(c) {
    var m = { unsupported: 'متصفحك لا يدعم التعرف على الصوت. جرّب Google Chrome أو Edge.', 'not-allowed': 'اسمح باستخدام الميكروفون من إعدادات المتصفح ثم أعد المحاولة.', 'service-not-allowed': 'اسمح باستخدام الميكروفون من إعدادات المتصفح ثم أعد المحاولة.', 'no-speech': 'لم أسمع صوتك. اضغط الميكروفون وابدأ الكلام مباشرة.', 'audio-capture': 'لا يوجد ميكروفون متاح، أو تطبيق آخر يستخدمه الآن.', network: 'التعرف على الصوت يحتاج اتصالاً بالإنترنت.', 'language-not-supported': 'لغة التعرّف الألمانية غير مدعومة في هذا المتصفح.' };
    return '<div class="lx-live">' + (m[c] || 'تعذّر التسجيل. أعد المحاولة.') + (c && c !== 'unsupported' ? '<small class="lx-code">' + esc(c) + '</small>' : '') + '</div>';
  }
  function fbHTML(res) {
    var p = res.pct, cls = p >= 85 ? 'g' : p >= 60 ? 'y' : 'r';
    var msg = p >= 85 ? 'ممتاز! نطقك واضح' : p >= 60 ? 'جيد، اقتربت من النطق الصحيح' : p >= 30 ? 'حاول مرة أخرى بتركيز أكبر' : 'لم أسمعك جيداً، أعد المحاولة';
    var span = function (w) { return '<span class="w-' + w.c + '">' + esc(w.w) + '</span>'; };
    return '<div class="lx-fb-head lx-' + cls + '"><div class="lx-ring" style="--p:' + p + '"><b>' + p + '%</b></div><div><strong>' + msg + '</strong><small>نسبة مطابقة تقريبية</small></div></div>' +
      '<div class="lx-fb-row"><span class="lx-fb-k">المطلوب</span><p class="lx-fb-p">' + res.E.map(span).join(' ') + '</p></div>' +
      '<div class="lx-fb-row"><span class="lx-fb-k">ما قلته</span><p class="lx-fb-p">' + (res.H.length ? res.H.map(span).join(' ') : '—') + '</p></div>';
  }

  /* تسجيل صوت المستخدم (اختياري، لمرحلة الدور الصوتي) */
  var recStream = null, recMR = null, recChunks = [], recTok = 0;
  function recStart() {
    var my = ++recTok;
    return new Promise(function (resolve) {
      try {
        if (!navigator.mediaDevices || !window.MediaRecorder) return resolve(null);
        navigator.mediaDevices.getUserMedia({ audio: true }).then(function (s) {
          if (my !== recTok) { s.getTracks().forEach(function (t) { t.stop(); }); return resolve(null); }
          recStream = s; recChunks = []; recMR = new MediaRecorder(s);
          recMR.ondataavailable = function (e) { if (e.data && e.data.size) recChunks.push(e.data); };
          recMR.start(); resolve(s.getAudioTracks()[0]);
        }).catch(function () { resolve(null); });
      } catch (e) { resolve(null); }
    });
  }
  function recStop(cb) {
    recTok++;
    var m = recMR, s = recStream; recMR = null; recStream = null;
    if (!m) { if (cb) cb(null); return; }
    m.onstop = function () {
      if (s) s.getTracks().forEach(function (t) { t.stop(); });
      if (cb) cb(recChunks.length ? URL.createObjectURL(new Blob(recChunks, { type: m.mimeType || 'audio/webm' })) : null);
    };
    try { m.stop(); } catch (e) { if (s) s.getTracks().forEach(function (t) { t.stop(); }); if (cb) cb(null); }
  }

  /* ================= بناء الواجهة (تصميم جديد) ================= */
  var title = dec(window.convTitle || document.title.split('|')[0] || '').trim();
  var STAGES = [['listen', 'استمع'], ['shadow', 'Shadowing'], ['role', 'دورك']];
  var SPEEDS = [0.7, 0.85, 1, 1.2], GRADS = 6;
  var autoLoop = false, spdI = 2, done = {};
  var libHref = (window.SX_LINKS && SX_LINKS.library && SX_LINKS.library !== '#') ? SX_LINKS.library : '/';

  document.documentElement.classList.add('lx-on');
  var app = ce('div', 'lx-app');
  app.innerHTML =
    '<header class="lx-head">' +
      '<div class="lx-top">' +
        '<div class="lx-title">' + esc(title) + '</div>' +
        '<button type="button" class="lx-tplay" id="lx-tplay" aria-label="تشغيل الصوت" style="display:none"><i class="fas fa-play"></i></button>' +
        '<button type="button" class="lx-hb" id="lx-setb" aria-label="التحكم والإعدادات"><i class="fas fa-sliders"></i></button>' +
        '<div class="lx-vw"><button type="button" class="lx-hb" id="lx-viewb" aria-label="العرض"><i class="fas fa-eye"></i></button>' +
          '<div class="lx-vm" id="lx-vm">' +
            '<button type="button" data-v="chat"><i class="fas fa-comments"></i> دردشة</button>' +
            '<button type="button" data-v="scene"><i class="fas fa-clapperboard"></i> مشهد</button>' +
            (WORDS.length ? '<button type="button" data-v="words"><i class="fas fa-clone"></i> مراجعة الكلمات</button>' : '') +
            '<button type="button" data-v="games"><i class="fas fa-gamepad"></i> لعبة الكلمات</button>' +
          '</div></div>' +
      '</div>' +
      '<nav class="lx-steps" id="lx-steps">' + STAGES.map(function (s, i) { return '<button type="button" class="lx-step" data-s="' + s[0] + '"><b>' + (i + 1) + '</b><span>' + s[1] + '</span></button>'; }).join('') + '</nav>' +
      '<div class="lx-tprog"><i id="lx-tprog"></i></div>' +
      '<div class="lx-now" id="lx-now"></div>' +
      '<div class="lx-vchip" id="lx-vchip"></div>' +
      '<div class="lx-sub" id="lx-sub"></div>' +
    '</header>' +
    '<main class="lx-scroll" id="lx-scroll"></main>' +
    '<footer class="lx-dock"><div id="lx-dockbody"></div></footer>' +
    '<div class="lx-load" id="lx-load"><div class="lx-ldbox"><div class="lx-ldring" id="lx-ldring"><b id="lx-ldpct">0%</b></div><h3>جاري تحميل المحادثة</h3><p id="lx-ldsub">جاري تحميل الأصوات</p><small id="lx-ldsm">هذا يحدث في أول مرة فقط (حوالي 120 ميجا) وتُحفظ بعدها في جهازك</small></div></div>' +
    '<div class="lx-ov" id="lx-sheet"></div><div class="lx-ov" id="lx-cards"></div><div class="lx-ov" id="lx-role"></div><div class="lx-ov center" id="lx-end"></div>' +
    '<div class="lx-launch" id="lx-launch"><div class="lx-lgrid">' +
      '<button type="button" class="lx-lt t1" data-l="chat"><i class="fas fa-comments"></i><b>دردشة</b><small>المحادثة بفقاعات مثل واتساب</small></button>' +
      '<button type="button" class="lx-lt t2" data-l="scene"><i class="fas fa-clapperboard"></i><b>مشهد</b><small>شخصان يتحدثان أمامك</small></button>' +
      '<button type="button" class="lx-lt t3" data-l="words"' + (WORDS.length ? '' : ' disabled') + '><i class="fas fa-clone"></i><b>مراجعة الكلمات أولًا</b><small>' + (WORDS.length ? 'بطاقات كلمات الدرس' : 'لا توجد كلمات في هذا الدرس') + '</small></button>' +
      '<button type="button" class="lx-lt t4" data-l="games"><i class="fas fa-gamepad"></i><b>لعبة الكلمات</b><small>ألعاب ممتعة بالأصوات والتحديات</small></button>' +
    '</div></div>';
  document.body.appendChild(app);

  var scroller = $('#lx-scroll', app), nowEl = $('#lx-now', app), dockEl = $('#lx-dockbody', app), subEl = $('#lx-sub', app);
  var sheetOv = $('#lx-sheet', app), cardsOv = $('#lx-cards', app), roleOv = $('#lx-role', app), endOv = $('#lx-end', app);
  var tplay = $('#lx-tplay', app), tprog = $('#lx-tprog', app), viewb = $('#lx-viewb', app), vm = $('#lx-vm', app), launch = $('#lx-launch', app);
  function setTplay(icon, fn) { if (!fn) { tplay.style.display = 'none'; tplay.onclick = null; return; } tplay.style.display = ''; tplay.innerHTML = fa(icon); tplay.onclick = fn; }
  function closeMenus() { vm.classList.remove('open'); }
  viewb.addEventListener('click', function (e) { e.stopPropagation(); vm.classList.toggle('open'); });
  app.addEventListener('click', function (e) { if (!e.target.closest('.lx-vw')) closeMenus(); });
  /* يُخفى الشريط السفلي تمامًا حين لا توجد فيه أزرار (المرحلة الأولى) */
  var dockMO = new MutationObserver(function () { app.classList.toggle('lx-nodock', !dockEl.children.length); });
  dockMO.observe(dockEl, { childList: true }); app.classList.add('lx-nodock');
  function status(t) { nowEl.textContent = t; }
  function toast(msg) {
    var t = ce('div', '', '<div style="position:fixed;bottom:130px;left:50%;transform:translateX(-50%);background:#17141f;color:#fff;padding:10px 20px;border-radius:30px;z-index:100000;font-size:14px;font-weight:800;font-family:Cairo,sans-serif;animation:lx-in .25s both;box-shadow:0 10px 30px rgba(0,0,0,.35)">' + msg + '</div>');
    document.body.appendChild(t); setTimeout(function () { t.remove(); }, 1900);
  }

  /* ---------- مساعدات الأزرار ---------- */
  function ic(label, icon, cls, fn) {
    var b = ce('button', 'lx-ic' + (cls ? ' ' + cls : ''), '<span class="ico">' + icon + '</span><small>' + label + '</small>');
    b.type = 'button'; if (fn) b.addEventListener('click', fn); return b;
  }
  function fa(n) { return '<i class="fas ' + n + '"></i>'; }
  function fab(icon, cls, fn) { var b = ce('button', 'lx-fab' + (cls ? ' ' + cls : ''), icon); b.type = 'button'; if (fn) b.addEventListener('click', fn); return b; }
  function rowEl() { var d = ce('div', 'lx-row'); dockEl.appendChild(d); return d; }
  function linkBtn(label, icon, fn) { var b = ce('button', 'lx-link', fa(icon) + ' ' + label); b.type = 'button'; b.addEventListener('click', fn); return b; }
  var stick = true;
  scroller.addEventListener('scroll', function () { stick = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 140; }, { passive: true });
  function toBottom() { stick = true; scroller.scrollTo({ top: scroller.scrollHeight, behavior: 'smooth' }); setTimeout(function () { if (stick) scroller.scrollTop = scroller.scrollHeight; }, 380); }
  if (window.ResizeObserver) new ResizeObserver(function () { if (stick) scroller.scrollTop = scroller.scrollHeight; }).observe(scroller);
  /* لوحة المفاتيح: نصغّر التطبيق على المساحة المرئية حتى يظهر الدوك وخانة الكتابة فوقها */
  if (window.visualViewport) {
    var vv = window.visualViewport, fitVV = function () {
      if (Math.abs(vv.height - window.innerHeight) < 80) { app.style.top = app.style.height = app.style.bottom = ''; }
      else { app.style.top = vv.offsetTop + 'px'; app.style.height = vv.height + 'px'; app.style.bottom = 'auto'; }
      if (stick) scroller.scrollTop = scroller.scrollHeight;
    };
    vv.addEventListener('resize', fitVV); vv.addEventListener('scroll', fitVV);
  }
  function copyText(txt) {
    var ok = function () { toast('✅ تم النسخ'); };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(ok, fb); else fb();
    function fb() { var ta = ce('textarea'); ta.value = txt; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); ok(); } catch (e) {} ta.remove(); }
  }

  /* ---------- الإعدادات (سرعة / تكرار / إعادة تلقائية / ترجمة) ---------- */
  var repaint = [];
  function applyTr() { app.classList.toggle('lx-hide-tr', !showTr); }
  var showTr = true;
  function paintSettings() { repaint.forEach(function (f) { f(); }); }
  function setSpeed(i) { spdI = i; speed = SPEEDS[i]; paintSettings(); }
  function setLoops(n) { loops = n; paintSettings(); }
  function setAuto(v) { autoLoop = v; paintSettings(); if (autoLoop && listenCtl && listenCtl.finished) listenCtl.play(); }
  function setTr(v) { showTr = v; applyTr(); paintSettings(); }
  function openSheet() {
    function seg(vals, cur, fnSet, fmt) { return '<div class="lx-seg">' + vals.map(function (v, i) { return '<button type="button" data-v="' + i + '" class="' + (cur(i) ? 'on' : '') + '">' + fmt(v) + '</button>'; }).join('') + '</div>'; }
    function pick(k) {
      var cur = userChars()[k] || '';
      return '<div class="lx-chpick" data-k="' + k + '"><button type="button" class="lx-chp auto' + (cur ? '' : ' on') + '" data-l="">حسب الدرس</button>' +
        LOOK_KEYS.map(function (key) { return '<button type="button" class="lx-chp' + (cur === key ? ' on' : '') + '" data-l="' + key + '" title="' + esc(LOOKS[key].n) + '">' + drawChar(LOOKS[key], k) + '<small>' + esc(LOOKS[key].n) + '</small></button>'; }).join('') + '</div>';
    }
    function draw() {
      sheetOv.innerHTML = '<div class="lx-box"><div class="lx-oxbar"><button type="button" class="lx-ox" data-k="xx" aria-label="إغلاق"><i class="fas fa-xmark"></i></button></div><h3>التحكم والإعدادات</h3><p>تنطبق على كل مراحل الدرس</p>' +
        '<div class="lx-set"><span>سرعة النطق</span>' + seg(SPEEDS, function (i) { return i === spdI; }, 0, function (v) { return v + '×'; }) + '</div>' +
        '<div class="lx-set"><span>تكرار كل رسالة</span>' + seg([1, 2, 3], function (i) { return loops === i + 1; }, 0, function (v) { return '×' + v; }) + '</div>' +
        '<div class="lx-set"><span>الشادوينج</span>' + seg(['تلقائي', 'يدوي'], function (i) { return (i === 0) === (LS.get('lx_shmode') !== 'manual'); }, 0, function (v) { return v; }) + '</div>' +
        '<div class="lx-set"><span>إعادة المحادثة تلقائياً</span><button type="button" class="lx-sw' + (autoLoop ? ' on' : '') + '" data-k="auto" aria-label="إعادة تلقائية"></button></div>' +
        '<div class="lx-set"><span>الترجمة العربية</span><button type="button" class="lx-sw' + (showTr ? ' on' : '') + '" data-k="tr" aria-label="الترجمة"></button></div>' +
        '<div class="lx-set col"><span>الشخصية الأولى (يمين)</span>' + pick(0) + '</div>' +
        '<div class="lx-set col"><span>الشخصية الثانية (يسار)</span>' + pick(1) + '</div>' +
        '<a class="lx-big dark" href="' + esc(libHref) + '"><i class="fas fa-book-open"></i> العودة إلى المكتبة</a>' +
        '<button type="button" class="lx-x" data-k="close">إغلاق</button></div>';
      var segs = $$('.lx-seg', sheetOv);
      $$('button', segs[0]).forEach(function (b) { b.addEventListener('click', function () { setSpeed(+b.getAttribute('data-v')); draw(); }); });
      $$('button', segs[1]).forEach(function (b) { b.addEventListener('click', function () { setLoops(+b.getAttribute('data-v') + 1); draw(); }); });
      $$('button', segs[2]).forEach(function (b) { b.addEventListener('click', function () {
        LS.set('lx_shmode', +b.getAttribute('data-v') === 0 ? 'auto' : 'manual'); draw();
        if (curStage === 'shadow') { stageShadow(); sheetOv.style.display = 'flex'; }
      }); });
      $('[data-k=auto]', sheetOv).addEventListener('click', function () { setAuto(!autoLoop); draw(); });
      $('[data-k=tr]', sheetOv).addEventListener('click', function () { setTr(!showTr); draw(); });
      $$('.lx-chpick', sheetOv).forEach(function (row) {
        var k = +row.getAttribute('data-k');
        $$('.lx-chp', row).forEach(function (b) { b.addEventListener('click', function () {
          var a = userChars().slice(0, 2); a[k] = b.getAttribute('data-l') || ''; LS.set('lx_chars', JSON.stringify(a));
          draw(); if (curStage === 'listen') { var keep = sheetOv.scrollTop; stageListen(); sheetOv.style.display = 'flex'; }
        }); });
      });
      $('[data-k=close]', sheetOv).addEventListener('click', function () { sheetOv.style.display = 'none'; });
      $('[data-k=xx]', sheetOv).addEventListener('click', function () { sheetOv.style.display = 'none'; });
    }
    draw(); sheetOv.style.display = 'flex';
  }
  sheetOv.addEventListener('click', function (e) { if (e.target === sheetOv) sheetOv.style.display = 'none'; });
  $('#lx-setb', app).addEventListener('click', openSheet);

  /* ---------- حالة المراحل ---------- */
  var runId = 0, userRole = 0, roleMode = 'voice', curStage = 'listen', lockTap = false, cancelTurn = null, roleStream = null, listenCtl = null;
  function closeStream() { if (roleStream) { roleStream.getTracks().forEach(function (t) { t.stop(); }); roleStream = null; } }
  function setStep(id) {
    var ids = STAGES.map(function (x) { return x[0]; }), cur = STAGES[Math.max(0, ids.indexOf(id))];
    $$('.lx-step', app).forEach(function (b) {
      var s = b.getAttribute('data-s'), n = ids.indexOf(s) + 1;
      b.classList.toggle('on', s === id); b.classList.toggle('done', !!done[s] && s !== id);
      b.querySelector('b').innerHTML = (done[s] && s !== id) ? '✓' : String(n);
    });
    var tt = $('#lx-ddt', app); if (tt) tt.textContent = cur[1];
    app.classList.toggle('lx-noplay', id === 'role');
  }
  function markDone(id) { done[id] = 1; setStep(curStage); }
  function reset() {
    app.classList.remove('lx-view-scene'); runId++; stopSpeak(); stopRec(); recStop(); lockTap = false; listenCtl = null; repaint = [];
    if (cancelTurn) { var c = cancelTurn; cancelTurn = null; c(); }
    closeStream();
    scroller.innerHTML = ''; dockEl.innerHTML = ''; subEl.innerHTML = ''; nowEl.textContent = ''; setTplay(null); tprog.style.width = '0'; closeMenus();
    sheetOv.style.display = 'none'; roleOv.style.display = 'none'; endOv.style.display = 'none'; cardsOv.style.display = 'none';
    app.classList.remove('lx-hide-me');
    setStep(curStage);
  }
  $$('.lx-step', app).forEach(function (b) { b.addEventListener('click', function () { closeMenus(); goStage(b.getAttribute('data-s')); }); });

  /* ================= مشهد الشخصين + مؤشر الكتابة + فواصل طبيعية ================= */
  var viewMode = LS.get('lx_view') === 'chat' ? 'chat' : 'scene';
  /* ===== أشكال الشخصيات (شباب): تُختار من إعدادات الدرس، أو لكل محادثة بـ window.convChars ===== */
  var LOOKS = {
    blond1:   { n: 'أشقر ١',        skin: '#f9dcc4', skinD: '#eabfa2', hair: '#e5bf5f', hi: '#f7de98', brow: '#b8913f', eye: '#3f86c9', style: 'quiff', beard: 0 },
    blond2:   { n: 'أشقر ٢',        skin: '#f7d6bd', skinD: '#e6b99c', hair: '#d9b560', hi: '#efd48a', brow: '#a98238', eye: '#4a9a7a', style: 'side',  beard: 1 },
    brunette: { n: 'كستنائي',       skin: '#f3cfb3', skinD: '#dcb08f', hair: '#4a3020', hi: '#6a4630', brow: '#3a2418', eye: '#5a3b24', style: 'side',  beard: 1 },
    dark:     { n: 'أسود الشعر',    skin: '#e0b08a', skinD: '#c99872', hair: '#1f1814', hi: '#3a2d25', brow: '#1f1814', eye: '#2a1d18', style: 'quiff', beard: 0 },
    redhead:  { n: 'أحمر الشعر',    skin: '#f8d9c6', skinD: '#e9bda6', hair: '#b8532a', hi: '#d7703f', brow: '#8f3f1f', eye: '#5b8f4a', style: 'short', beard: 2 },
    beard:    { n: 'لحية كاملة',    skin: '#f0c4a0', skinD: '#d9a784', hair: '#2b1d16', hi: '#4a3428', brow: '#2b1d16', eye: '#2a1d18', style: 'short', beard: 2 },
    glasses:  { n: 'نظارة',         skin: '#e3b08a', skinD: '#c99872', hair: '#5a3a22', hi: '#7a5434', brow: '#3a2418', eye: '#2a1d18', style: 'short', beard: 0, glasses: true },
    dark2:    { n: 'أسمر بلحية',    skin: '#dfae88', skinD: '#c4946d', hair: '#17110e', hi: '#34271f', brow: '#17110e', eye: '#5a3b24', style: 'side',  beard: 2, face: 'sq', brw: 4 },
    curly:    { n: 'شعر مجعّد',     skin: '#e8bd98', skinD: '#d2a37c', hair: '#3a2418', hi: '#5a3a28', brow: '#2b1a10', eye: '#5a3b24', style: 'curly', beard: 1 },
    afro:     { n: 'أفرو',          skin: '#8d5a3b', skinD: '#744630', hair: '#15100d', hi: '#2b211b', brow: '#15100d', eye: '#2a1a10', style: 'afro',  beard: 1, brw: 3.6 },
    bald:     { n: 'أصلع بلحية',    skin: '#e6b48d', skinD: '#cf9a72', hair: '#2b1d16', hi: '#4a3428', brow: '#2b1d16', eye: '#3a2a1a', style: 'bald',  beard: 2, face: 'sq', brw: 3.8 },
    longhair: { n: 'شعر طويل',      skin: '#f3cfb3', skinD: '#dcb08f', hair: '#6a4426', hi: '#8a6038', brow: '#4a3018', eye: '#4a7a9a', style: 'long',  beard: 0 },
    bun:      { n: 'كعكة شعر',      skin: '#e3b08a', skinD: '#c99872', hair: '#1f1814', hi: '#3a2d25', brow: '#1f1814', eye: '#2a1d18', style: 'bun',   beard: 2 },
    cap:      { n: 'بقبعة',         skin: '#f0c4a0', skinD: '#d9a784', hair: '#d9b560', hi: '#efd48a', brow: '#a98238', eye: '#3f86c9', style: 'side',  beard: 1, cap: '#17141f' },
    beanie:   { n: 'بطاقية',        skin: '#f3cfb3', skinD: '#dcb08f', hair: '#5a3a22', hi: '#7a5434', brow: '#3a2418', eye: '#4a9a7a', style: 'side',  beard: 0, beanie: '#4f46e5' },
    sunny:    { n: 'نظارة شمس',     skin: '#f0c4a0', skinD: '#d9a784', hair: '#e5bf5f', hi: '#f7de98', brow: '#b8913f', eye: '#3f86c9', style: 'quiff', beard: 0, glasses: 'sun' },
    elder:    { n: 'كبير السن',     skin: '#eec7a5', skinD: '#d6a984', hair: '#cfcfd6', hi: '#ececf2', brow: '#aaaab4', eye: '#4a7a9a', style: 'short', beard: 2, glasses: true, face: 'sq' },
    buzz:     { n: 'حلاقة قصيرة',   skin: '#a86f4c', skinD: '#8f5a3b', hair: '#15100d', hi: '#2b211b', brow: '#15100d', eye: '#2a1a10', style: 'buzz',  beard: 1, face: 'sq', brw: 3.8 },
    olive:    { n: 'نظارة دائرية',  skin: '#d9a67e', skinD: '#c18c63', hair: '#1b1410', hi: '#3a2d25', brow: '#1b1410', eye: '#4a3020', style: 'quiff', beard: 1, glasses: 'round' },
    ginger:   { n: 'زنجبيلي مجعّد', skin: '#f8d9c6', skinD: '#e9bda6', hair: '#c0602e', hi: '#e08040', brow: '#8f3f1f', eye: '#5b8f4a', style: 'curly', beard: 0 }
  };
  var LOOK_KEYS = Object.keys(LOOKS);
  var FACE = {
    rd: 'M40 72C40 50 53 35 70 35C87 35 100 50 100 72C100 99 87 115 70 115C53 115 40 99 40 72Z',
    sq: 'M39 72C39 50 52 35 70 35C88 35 101 50 101 72C101 90 98 104 91 111C86 116 78 119 70 119C62 119 54 116 49 111C42 104 39 90 39 72Z'
  };
  var SHIRT = ['#dc143c', '#4f46e5'];
  var SIDE = 'M38 70C34 46 46 26 70 25C94 24 106 46 102 70C99 58 92 49 78 44C64 50 48 50 44 46C41 52 39 60 38 70Z';
  var HAIRS = {
    short: { f: 'M38 70c-4-27 13-43 32-43s36 15 32 43c-4-10-8-18-14-22-10 6-30 8-44 2-4 6-5 14-6 20z' },
    quiff: { f: 'M38 70C33 48 42 24 68 19C92 14 108 34 102 70C98 58 92 50 82 47C70 52 52 54 44 48C41 54 39 62 38 70Z', q: 1 },
    side:  { f: SIDE, s: 1 },
    buzz:  { f: 'M41 66C40 46 52 36 70 36C88 36 100 46 99 66C94 54 84 48 70 48C56 48 46 54 41 66Z', o: 0.85 },
    afro:  { b: '<circle cx="70" cy="52" r="45"/>', f: 'M42 58C43 42 55 33 70 33C85 33 97 42 98 58C92 48 82 44 70 44C58 44 48 48 42 58Z' },
    curly: { b: '<circle cx="46" cy="50" r="15"/><circle cx="62" cy="36" r="16"/><circle cx="82" cy="35" r="16"/><circle cx="98" cy="48" r="15"/><circle cx="106" cy="66" r="9"/><circle cx="34" cy="66" r="9"/>', f: 'M40 66C41 46 54 36 70 36C86 36 99 46 100 66C94 54 84 46 70 46C56 46 46 54 40 66Z' },
    long:  { b: '<path d="M30 62C28 30 48 18 70 18C92 18 112 30 110 62L116 136C100 146 40 146 24 136Z"/>', f: SIDE, s: 1 },
    bun:   { b: '<circle cx="70" cy="22" r="13"/>', f: SIDE, s: 1 },
    bald:  { f: '' }
  };
  function userChars() { try { var a = JSON.parse(LS.get('lx_chars') || 'null'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
  function lookName(k) {
    var u = userChars()[k]; if (u && LOOKS[u]) return u;
    var n = Array.isArray(window.convChars) ? String(window.convChars[k] || '') : '';
    return LOOKS[n] ? n : ['blond1', 'dark2'][k];
  }
  function lookOf(k) { return LOOKS[lookName(k)]; }
  function drawChar(c, k) {
    var sk = c.skin, dk = c.skinD, h = c.hair, dir = k === 1 ? 1 : -1, fx = dir * 6, shirt = SHIRT[k], HS = HAIRS[c.style] || HAIRS.short, rot = 'rotate(' + (dir * 4) + ' 70 112)';
    var ear = dir === 1 ? '<circle cx="39" cy="79" r="6.5" fill="' + sk + '"/>' : '<circle cx="101" cy="79" r="6.5" fill="' + sk + '"/>';
    var hairX = HS.q ? '<path d="M52 33q16-13 38-5" stroke="' + c.hi + '" stroke-width="3.5" fill="none" stroke-linecap="round" opacity=".85"/>'
              : HS.s ? '<path d="M60 31q14-7 30-3" stroke="' + c.hi + '" stroke-width="3" fill="none" stroke-linecap="round" opacity=".8"/><path d="M62 29q5 8 7 17" stroke="' + dk + '" stroke-width="1.6" fill="none" opacity=".5"/>'
              : c.style === 'bald' ? '<ellipse cx="62" cy="44" rx="12" ry="5" fill="#fff" opacity=".22"/>' : '';
    var hat = '';
    if (c.cap) hat = '<path d="M38 62C38 36 54 26 70 26C86 26 102 36 102 62Z" fill="' + c.cap + '"/><g transform="' + (dir === -1 ? 'translate(140,0) scale(-1,1)' : '') + '"><path d="M96 60Q118 59 126 68Q110 73 94 66Z" fill="' + c.cap + '"/></g>';
    if (c.beanie) hat = '<path d="M37 64C36 34 54 22 70 22C86 22 104 34 103 64Z" fill="' + c.beanie + '"/><rect x="36" y="57" width="68" height="12" rx="6" fill="' + c.beanie + '"/><rect x="36" y="57" width="68" height="12" rx="6" fill="#000" opacity=".16"/>';
    var gl = '';
    if (c.glasses === true) gl = '<g fill="rgba(255,255,255,.12)" stroke="#2b2b35" stroke-width="2.2"><rect x="49" y="64" width="19" height="15" rx="6"/><rect x="72" y="64" width="19" height="15" rx="6"/><path d="M68 71h4"/></g>';
    else if (c.glasses === 'round') gl = '<g fill="rgba(255,255,255,.12)" stroke="#2b2b35" stroke-width="2.2"><circle cx="58.5" cy="72" r="9.5"/><circle cx="81.5" cy="72" r="9.5"/><path d="M68 72h4"/></g>';
    else if (c.glasses === 'sun') gl = '<g fill="#17141f"><rect x="48" y="65" width="21" height="14" rx="6"/><rect x="71" y="65" width="21" height="14" rx="6"/></g><path d="M69 70h2" stroke="#17141f" stroke-width="2.4"/><path d="M52 68l6-1" stroke="#fff" stroke-width="1.6" opacity=".35" stroke-linecap="round"/>';
    return '<svg class="lx-chsvg" viewBox="0 0 140 190" aria-hidden="true">' +
      '<path d="M6 190C6 146 38 128 70 128s64 18 64 62z" fill="' + shirt + '"/>' +
      '<path d="M70 128v62" stroke="rgba(0,0,0,.1)" stroke-width="2"/>' +
      (HS.b ? '<g fill="' + h + '" transform="' + rot + '">' + HS.b + '</g>' : '') +
      '<path d="M54 128L70 154 86 128z" fill="' + dk + '"/>' +
      '<rect x="60" y="102" width="20" height="30" rx="9" fill="' + dk + '"/>' +
      '<g transform="' + rot + '">' +
        ear +
        '<path d="' + FACE[c.face || 'rd'] + '" fill="' + sk + '"/>' +
        (c.beard === 2 ? '<path transform="translate(' + (dir * 4) + ',0)" d="M40 80c1 28 14 38 30 38s29-10 30-38c-4 9-9 13-15 15-9-4-21-4-30 0-6-2-11-6-15-15z" fill="' + h + '" opacity=".96"/>' : '') +
        (c.beard === 1 ? '<path d="M44 84c2 24 12 32 26 32s24-8 26-32c-6 14-14 20-26 20s-20-6-26-20z" fill="' + h + '" opacity=".22"/>' : '') +
        (HS.f ? '<path d="' + HS.f + '" fill="' + h + '"' + (HS.o ? ' opacity="' + HS.o + '"' : '') + '/>' : '') + hairX + hat +
        '<g transform="translate(' + fx + ',0)">' +
          '<ellipse cx="50" cy="86" rx="7" ry="4.5" fill="#ff8a78" opacity=".22"/><ellipse cx="90" cy="86" rx="7" ry="4.5" fill="#ff8a78" opacity=".22"/>' +
          '<path d="M50 62q8-5 16-1M74 61q8-4 16 1" stroke="' + c.brow + '" stroke-width="' + (c.brw || 3) + '" fill="none" stroke-linecap="round"/>' +
          '<ellipse cx="58" cy="72" rx="6.4" ry="5.2" fill="#fff"/><ellipse cx="82" cy="72" rx="6.4" ry="5.2" fill="#fff"/>' +
          '<circle cx="' + (59 + dir * 2.4) + '" cy="72.5" r="3.7" fill="' + c.eye + '"/><circle cx="' + (83 + dir * 2.4) + '" cy="72.5" r="3.7" fill="' + c.eye + '"/>' +
          '<circle cx="' + (59 + dir * 2.4) + '" cy="72.5" r="1.7" fill="#1b1410"/><circle cx="' + (83 + dir * 2.4) + '" cy="72.5" r="1.7" fill="#1b1410"/>' +
          '<rect class="lx-lid" x="51" y="65" width="14" height="12" fill="' + sk + '"/><rect class="lx-lid" x="75" y="65" width="14" height="12" fill="' + sk + '"/>' +
          gl +
          '<path d="M70 74q' + (5 * dir) + ' 9 ' + (2 * dir) + ' 12q' + (-4 * dir) + ' 1 ' + (-7 * dir) + ' 0" stroke="' + dk + '" stroke-width="2" fill="none" stroke-linecap="round"/>' +
          '<path class="lx-sm" d="M61 96q9 7 18 0" fill="none" stroke="' + (c.beard === 2 ? '#f1c6b5' : '#c0665a') + '" stroke-width="3" stroke-linecap="round"/>' +
          '<ellipse class="lx-mo" cx="70" cy="98" rx="7.5" ry="6.5" fill="#5e1f1a"/>' +
        '</g>' +
      '</g></svg>';
  }
  function charSVG(k) { return drawChar(lookOf(k), k); }
  var SCENES = ['day', 'night', 'plain', 'home', 'cafe', 'clinic', 'street', 'office'];
  function sceneKind() {
    var v = String(window.convScene || '').toLowerCase().trim();
    if (v.charAt(0) === '#') return v;
    return SCENES.indexOf(v) > -1 ? v : 'day';
  }
  function sceneBG(kind) {
    var h = '<svg viewBox="0 0 400 400" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">', e = '</svg>';
    if (kind.charAt(0) === '#') return h + '<defs><radialGradient id="lxpc" cx=".5" cy=".4" r=".8"><stop offset="0" stop-color="#fff" stop-opacity=".28"/><stop offset="1" stop-color="#000" stop-opacity=".25"/></radialGradient></defs><rect width="400" height="400" fill="' + kind + '"/><rect width="400" height="400" fill="url(#lxpc)"/><rect y="322" width="400" height="78" fill="#000" opacity=".18"/>' + e;
    if (kind === 'plain') return h + '<defs><linearGradient id="lxpl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f7f1ea"/><stop offset="1" stop-color="#e7dccf"/></linearGradient></defs><rect width="400" height="400" fill="url(#lxpl)"/><circle cx="90" cy="110" r="90" fill="#fff" opacity=".35"/><circle cx="330" cy="190" r="120" fill="#fff" opacity=".25"/><rect y="322" width="400" height="78" fill="#d6c7b6"/><rect y="316" width="400" height="8" fill="#e4d7c8"/>' + e;
    if (kind === 'night') return h + '<defs><linearGradient id="lxnt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0b1226"/><stop offset="1" stop-color="#26324f"/></linearGradient></defs><rect width="400" height="400" fill="url(#lxnt)"/><g fill="#fff"><circle cx="40" cy="60" r="1.6"/><circle cx="110" cy="130" r="1.2"/><circle cx="170" cy="50" r="1.8"/><circle cx="230" cy="110" r="1.2"/><circle cx="300" cy="40" r="1.5"/><circle cx="360" cy="140" r="1.3"/><circle cx="70" cy="200" r="1.1"/><circle cx="260" cy="190" r="1.3"/></g><circle cx="320" cy="82" r="30" fill="#f3f1e6"/><circle cx="332" cy="74" r="26" fill="#0f1830"/><path d="M0 300V250h30v-30h36v40h26v-60h34v70h30v-40h40v50h36v-80h38v90h30v-30h40v60h34V190h36v200H0z" fill="#101a33"/><g fill="#ffd36b" opacity=".85"><rect x="40" y="262" width="7" height="9"/><rect x="108" y="248" width="7" height="9"/><rect x="190" y="268" width="7" height="9"/><rect x="262" y="246" width="7" height="9"/><rect x="340" y="236" width="7" height="9"/></g><rect y="322" width="400" height="78" fill="#0a1020"/><rect y="318" width="400" height="6" fill="#1b2744"/>' + e;
    if (kind === 'cafe') return h + '<rect width="400" height="400" fill="#f1d9bd"/><rect width="400" height="96" fill="#e3bd93"/><rect x="26" y="142" width="160" height="9" rx="3" fill="#8a5a3b"/><rect x="38" y="118" width="22" height="24" rx="5" fill="#fff"/><rect x="74" y="122" width="20" height="20" rx="5" fill="#dc143c"/><rect x="108" y="116" width="22" height="26" rx="5" fill="#fff"/><rect x="144" y="124" width="26" height="18" rx="5" fill="#7aa2d6"/><rect x="236" y="118" width="130" height="96" rx="8" fill="#bfe3ff" stroke="#8a5a3b" stroke-width="7"/><path d="M301 118v96M236 166h130" stroke="#8a5a3b" stroke-width="4"/><path d="M120 0v38M292 0v50" stroke="#5b3a29" stroke-width="3"/><circle cx="120" cy="48" r="17" fill="#f7c85a"/><circle cx="292" cy="60" r="17" fill="#f7c85a"/><circle cx="120" cy="48" r="30" fill="#f7c85a" opacity=".25"/><circle cx="292" cy="60" r="30" fill="#f7c85a" opacity=".25"/><rect y="320" width="400" height="80" fill="#8a5a3b"/><rect y="312" width="400" height="12" fill="#a8704a"/>' + e;
    if (kind === 'clinic') return h + '<rect width="400" height="400" fill="#e6f3fb"/><rect x="168" y="56" width="64" height="64" rx="12" fill="#fff"/><path d="M190 70h20v16h16v20h-16v16h-20v-16h-16V86h16z" fill="#16a34a"/><rect x="40" y="150" width="96" height="104" rx="8" fill="#cfe8ff" stroke="#fff" stroke-width="7"/><path d="M88 150v104M40 202h96" stroke="#fff" stroke-width="4"/><rect x="288" y="168" width="76" height="96" rx="8" fill="#fff"/><path d="M300 190h52M300 210h52M300 230h32" stroke="#b7c9d6" stroke-width="5" stroke-linecap="round"/><rect y="322" width="400" height="78" fill="#cfd8dc"/><rect y="316" width="400" height="8" fill="#e1e8ec"/>' + e;
    if (kind === 'street') return h + '<defs><linearGradient id="lxst" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#bfe0fb"/><stop offset="1" stop-color="#e8f4fe"/></linearGradient></defs><rect width="400" height="400" fill="url(#lxst)"/><circle cx="330" cy="70" r="30" fill="#ffe9a8"/><rect x="14" y="116" width="96" height="206" fill="#d98c6a"/><rect x="120" y="70" width="84" height="252" fill="#8fa3c7"/><rect x="214" y="132" width="104" height="190" fill="#e0b25c"/><rect x="328" y="100" width="72" height="222" fill="#a98fc7"/><g fill="#fff" opacity=".85"><rect x="30" y="136" width="18" height="18"/><rect x="68" y="136" width="18" height="18"/><rect x="30" y="178" width="18" height="18"/><rect x="68" y="178" width="18" height="18"/><rect x="136" y="96" width="18" height="18"/><rect x="168" y="96" width="18" height="18"/><rect x="136" y="142" width="18" height="18"/><rect x="168" y="142" width="18" height="18"/><rect x="234" y="152" width="18" height="18"/><rect x="274" y="152" width="18" height="18"/></g><rect y="320" width="400" height="80" fill="#6b7280"/><rect y="312" width="400" height="10" fill="#9ca3af"/><path d="M0 366h400" stroke="#fff" stroke-width="4" stroke-dasharray="28 18"/>' + e;
    if (kind === 'office') return h + '<rect width="400" height="400" fill="#eef1f6"/><rect x="36" y="64" width="150" height="116" rx="8" fill="#bfe3ff" stroke="#fff" stroke-width="7"/><path d="M48 172V142h18v30M74 172V122h22v50M106 172V137h20v35M134 172V128h26v44" fill="#7c8db5"/><rect x="248" y="76" width="124" height="84" rx="8" fill="#fff" stroke="#cbd5e1" stroke-width="5"/><path d="M264 102h62M264 122h92M264 142h42" stroke="#94a3b8" stroke-width="5" stroke-linecap="round"/><rect x="36" y="214" width="40" height="70" rx="6" fill="#cbd5e1"/><rect y="320" width="400" height="80" fill="#b08968"/><rect y="312" width="400" height="12" fill="#c9a07a"/>' + e;
    /* home */
    return h + '<defs><linearGradient id="lxhm" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fde8d8"/><stop offset="1" stop-color="#f8cfae"/></linearGradient></defs><rect width="400" height="400" fill="url(#lxhm)"/><rect x="250" y="66" width="112" height="134" rx="8" fill="#bfe3ff" stroke="#fff" stroke-width="8"/><path d="M306 66v134M250 133h112" stroke="#fff" stroke-width="5"/><rect x="40" y="196" width="10" height="126" fill="#6b4a33"/><circle cx="45" cy="176" r="30" fill="#f7d36b"/><circle cx="45" cy="176" r="52" fill="#f7d36b" opacity=".2"/><rect x="132" y="252" width="116" height="70" rx="14" fill="#7aa2d6" opacity=".6"/><rect y="320" width="400" height="80" fill="#c98f66"/><rect y="312" width="400" height="10" fill="#d8a47d"/>' + e;
  }
  function makeScene() {
    var el = ce('div', 'lx-scene');
    el.innerHTML = '<div class="lx-sc-bg">' + sceneBG(sceneKind()) + '</div>' +
      '<div class="lx-sc-cap s0"><span class="lx-sc-nm"></span><span class="lx-sc-de" dir="ltr"></span><span class="lx-sc-ar" dir="rtl"></span></div>' +
      '<div class="lx-ch c1" data-k="1">' + charSVG(1) + '<span class="lx-ch-n">' + esc(names[1] || '') + '</span></div>' +
      '<div class="lx-ch c0" data-k="0">' + charSVG(0) + '<span class="lx-ch-n">' + esc(names[0] || '') + '</span></div>';
    var cap = $('.lx-sc-cap', el), nm = $('.lx-sc-nm', cap), de = $('.lx-sc-de', cap), ar = $('.lx-sc-ar', cap), chs = $$('.lx-ch', el), timers = [];
    nm.textContent = ''; de.textContent = ''; ar.textContent = '';
    function clearT() { timers.forEach(clearTimeout); timers = []; }
    function clear() { clearT(); chs.forEach(function (c) { c.classList.remove('talk', 'think', 'hear'); }); }
    function who(k) { return chs.filter(function (c) { return +c.getAttribute('data-k') === k; })[0]; }
    return {
      el: el,
      say: function (l) {
        clear(); var c = who(l.spk);
        if (c) c.classList.add('talk');
        cap.className = 'lx-sc-cap s' + l.spk; void cap.offsetWidth; cap.className += ' pop';
        nm.textContent = l.name;
        de.innerHTML = l.de.split(/\s+/).map(function (w) { return '<span class="w">' + esc(w) + '</span>'; }).join(' ');
        ar.textContent = l.ar || '';
      },
      /* تظليل الكلمات بالتتابع مع الصوت */
      hl: function (dur) {
        clearT(); var ws = $$('.w', de), tot = 0, acc = 0;
        if (!(dur > 0)) dur = 1500;
        ws.forEach(function (w) { tot += w.textContent.length + 1; });
        ws.forEach(function (w) {
          var t = Math.round(dur * 0.9 * acc / tot); acc += w.textContent.length + 1;
          timers.push(setTimeout(function () { w.classList.add('on'); }, t));
        });
      },
      typing: function (l) {
        clear(); var c = who(l.spk); if (c) c.classList.add('think');
        cap.className = 'lx-sc-cap dots s' + l.spk; nm.textContent = l.name; de.innerHTML = '<i></i><i></i><i></i>'; ar.textContent = '';
      },
      stop: function () { clear(); $$('.w', de).forEach(function (w) { w.classList.add('on'); }); }
    };
  }
  /* مؤشر "يكتب…" يبقى ظاهرًا حتى يبدأ الصوت فعلًا */
  function typingStart(l, i, scn) {
    var ms = i === 0 ? 350 : Math.min(850, 260 + l.de.length * 9);
    var d = ce('div', 'lx-msg ' + (l.side === 'right' ? 'right' : 'left'), '<span class="lx-av s' + l.spk + '">' + esc(l.name.charAt(0).toUpperCase()) + '</span><div class="lx-bub lx-tdots"><i></i><i></i><i></i></div>');
    scroller.appendChild(d); toBottom(); if (scn) scn.typing(l);
    return { ms: ms, remove: function () { if (d.parentNode) d.remove(); } };
  }
  /* فاصل متغيّر بين الأدوار: الردود القصيرة أسرع، ونفس المتحدث أسرع */
  function gapFor(i) {
    var n = L[i + 1]; if (!n) return 500;
    var base = [220, 380, 160, 300, 200, 420, 260][i % 7];
    if (n.spk === L[i].spk) return 200;
    return n.de.split(/\s+/).length <= 2 ? Math.round(base * 0.6) : base;
  }
  /* ---------- فقاعة المحادثة ---------- */
  function bubble(l, i) {
    var wrap = ce('div', 'lx-msg ' + (l.side === 'right' ? 'right' : 'left'));
    wrap.innerHTML = '<span class="lx-av s' + l.spk + '">' + esc(l.name.charAt(0).toUpperCase()) + '</span>' +
      '<div class="lx-bub g' + (i % GRADS) + '"><span class="lx-eq"><i></i><i></i><i></i></span><span class="lx-nm">' + esc(l.name) + '</span><span class="lx-de" dir="ltr">' + esc(l.de) + '</span>' +
      (l.ar ? '<span class="lx-ar" dir="rtl">' + esc(l.ar) + '</span>' : '') + '</div>';
    var b = $('.lx-bub', wrap);
    b.addEventListener('click', function () {
      var de = $('.lx-de', b);
      if (b.classList.contains('lx-blur')) { b.classList.remove('lx-blur'); return; }
      if (b.classList.contains('me') && app.classList.contains('lx-hide-me')) { de.classList.toggle('rev'); return; }
      if (lockTap) return;
      $$('.lx-bub.on', scroller).forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on'); speakP(l.de, l.spk).then(function () { b.classList.remove('on'); });
    });
    scroller.appendChild(wrap); toBottom();
    return b;
  }
  function hl(b, on) { if (b) b.classList.toggle('on', on); }

  /* ---------- بطاقة التقييم + الميكروفون (التعرّف وحده، بدون تسجيل متزامن) ---------- */
  function showFb(html) {
    var f = $('#lx-fb', scroller);
    if (!f) { f = ce('div', 'lx-card'); f.id = 'lx-fb'; scroller.appendChild(f); }
    f.innerHTML = html; toBottom();
  }
  function clearFb() { var f = $('#lx-fb', scroller); if (f) f.remove(); }
  function bindScoreMic(b, getExp, onScore) {
    b.addEventListener('click', function () {
      if (b.classList.contains('active')) { stopRec(); return; }
      var exp = getExp(), heard = false;
      b.classList.add('active');
      showFb('<div class="lx-live">أنا أسمعك… تحدّث الآن 🎤</div>');
      listen(exp, {
        interim: function (t) { heard = true; showFb('<div class="lx-live ltr">' + esc(t) + '</div>'); },
        done: function (t, res) { heard = true; showFb(fbHTML(res)); onScore(res.pct); },
        error: function (c) { b.classList.remove('active'); if (c === 'aborted') { if (!heard) clearFb(); return; } showFb(errMsg(c)); },
        end: function (got) { b.classList.remove('active'); if (!got && !heard) showFb(errMsg('no-speech')); }
      });
    });
  }

  /* ================= المرحلة 1: استمع ================= */
  function stageListen() {
    curStage = 'listen'; reset(); if (viewMode === 'scene') app.classList.add('lx-view-scene');
    var ctl = listenCtl = { finished: false, play: play }, scn = null;
    scroller.innerHTML = '<div class="lx-hero"><div class="lx-duo">' + charSVG(1) + charSVG(0) + '</div><h2>' + esc(title || 'المحادثة') + '</h2><p>استمع للمحادثة كاملة، واضغط على أي رسالة لسماعها وحدها.</p><button type="button" class="lx-cta" id="lx-cta"><i class="fas fa-play"></i> ابدأ المحادثة</button></div>';
    $('#lx-cta', scroller).addEventListener('click', play);
    status('اضغط ▶ للبدء');
    function setPlay(mode) {
      setTplay(mode === 'stop' ? 'fa-stop' : mode === 'replay' ? 'fa-rotate-right' : 'fa-play',
        mode === 'stop' ? function () { runId++; stopSpeak(); lockTap = false; ctl.finished = false; $$('.lx-bub.on', scroller).forEach(function (x) { x.classList.remove('on'); }); status('تم الإيقاف'); setPlay('replay'); } : play);
    }
    setPlay('play');
    async function play() {
      var run = ++runId; stopSpeak(); lockTap = true; ctl.finished = false; setPlay('stop');
      if (PIPER.on && PIPER.state === 'ready') { await prepAll(run, function (n) { status('جاري تجهيز المحادثة… ' + n + ' / ' + L.length); }); if (run !== runId) return; }
      scroller.innerHTML = ''; scn = makeScene(); scroller.appendChild(scn.el);
      var bar = tprog;
      for (var i = 0; i < L.length; i++) {
        if (run !== runId) return;
        status(L[i].name + ' يتحدث…  ' + (i + 1) + ' / ' + L.length); bar.style.width = Math.round(100 * i / L.length) + '%';
        pre(i + 1);
        var tb = typingStart(L[i], i, scn), b = null;
        await wait(tb.ms);
        if (run !== runId) { tb.remove(); return; }
        for (var k = 0; k < loops; k++) {
          var ok = await speakP(L[i].de, L[i].spk, function (d) {
            tb.remove();
            if (!b) { b = bubble(L[i], i); hl(b, true); }
            scn.say(L[i]); scn.hl(d);
          });
          if (!ok || run !== runId) return;
          if (k < loops - 1) await wait(800);
        }
        if (!b) { tb.remove(); b = bubble(L[i], i); }
        hl(b, false); scn.stop();
        await wait(gapFor(i));
      }
      if (run !== runId) return;
      bar.style.width = '100%'; lockTap = false; ctl.finished = true; setPlay('replay'); markDone('listen');
      status(autoLoop ? 'اكتملت — ستُعاد المحادثة…' : 'اكتملت المحادثة ✅ الخطوة التالية: Shadowing');
      if (!autoLoop) {
        var nb = ce('button', 'lx-big green lx-cta-next', 'انتقل إلى Shadowing ' + fa('fa-arrow-left')); nb.type = 'button';
        nb.addEventListener('click', function () { goStage('shadow'); }); scroller.appendChild(nb); toBottom();
      }
      if (autoLoop) setTimeout(function () { if (run === runId && autoLoop) play(); }, 1800);
    }
  }

  /* ================= المرحلة 2: Shadowing ================= */
  function stageShadow() {
    curStage = 'shadow'; reset();
    var idx = 0, hide = false, shRec = [], tok = 0, running = false, recording = false, recFinish = null, cmpAudio = null;
    var auto = LS.get('lx_shmode') !== 'manual', REC_MS = 10000;
    var nav = ce('div', 'lx-nav'); dockEl.appendChild(nav);
    var prev = ce('button', 'lx-arrow', fa('fa-chevron-right')); prev.type = 'button'; prev.setAttribute('aria-label', 'السابق');
    var nxt = ce('button', 'lx-arrow go', fa('fa-chevron-left')); nxt.type = 'button'; nxt.setAttribute('aria-label', 'الجملة التالية');
    var mid = ce('div', 'lx-mid'), cnt = ce('span', 'lx-count'), dots = ce('div', 'lx-dots');
    L.forEach(function (l, i) { var d = ce('b'); d.addEventListener('click', function () { go(i); }); dots.appendChild(d); });
    mid.appendChild(cnt); mid.appendChild(dots); nav.appendChild(prev); nav.appendChild(mid); nav.appendChild(nxt);
    var r = rowEl();
    var hear = ic('الأصل', fa('fa-volume-high'), '', function () { cancelAll(); hear$(); });
    var mic = fab(fa('fa-microphone'), '', null); mic.setAttribute('aria-label', 'المايك');
    var mine = ic('تسجيلي', fa('fa-headphones'), 'green', function () { if (shRec[idx] && !running) { cancelAll(); playUrl(shRec[idx], tok); } });
    var hideB = ic('النص', fa('fa-eye-slash'), '', function () { hide = !hide; hideB.classList.toggle('on', hide); var b = $('.lx-bub', scroller); if (b) b.classList.toggle('lx-blur', hide); });
    [hear, mic, mine, hideB].forEach(function (x) { r.appendChild(x); });
    function setBtns() {
      hear.disabled = running; mine.disabled = running || !shRec[idx];
      setTplay(auto ? (running ? 'fa-stop' : 'fa-play') : 'fa-volume-high', auto ? toggleAuto : function () { cancelAll(); hear$(); });
    }
    function hear$() { status('🎧 النطق الأصلي'); speakP(L[idx].de, L[idx].spk); }
    function cancelAll() {
      tok++; running = false; stopSpeak();
      if (cmpAudio) { try { cmpAudio.pause(); } catch (e) {} cmpAudio = null; }
      if (recording) { recording = false; recFinish = null; mic.classList.remove('rec'); recStop(); }
      clearFb(); setBtns();
    }
    function playUrl(url, my) {
      return new Promise(function (res) {
        var a = new Audio(url); cmpAudio = a;
        a.onended = a.onerror = function () { if (cmpAudio === a) cmpAudio = null; res(my === tok); };
        var p = a.play(); if (p && p.catch) p.catch(function () { res(false); });
      });
    }
    /* يفتح المايك ويغلقه تلقائيًا بعد maxMs (أو عند ضغط المستخدم على المايك) ثم يعيد رابط التسجيل */
    function recordWindow(my, maxMs) {
      return new Promise(function (resolve) {
        var fin = false, t0 = 0, timer = null;
        function finish() {
          if (fin) return; fin = true; clearInterval(timer); recording = false; recFinish = null; mic.classList.remove('rec');
          recStop(function (url) { resolve(my === tok ? url : null); });
        }
        function tick() {
          if (my !== tok) { finish(); return; }
          var left = Math.max(0, Math.ceil((maxMs - (Date.now() - t0)) / 1000));
          status('🎙️ تحدّث الآن' + (maxMs <= 20000 ? ' · ' + left + ' ث' : ' · اضغط المايك للإيقاف'));
          if (Date.now() - t0 >= maxMs) finish();
        }
        recStart().then(function (track) {
          if (my !== tok) { recStop(); resolve(null); return; }
          if (!track) { showFb(errMsg('audio-capture')); resolve(null); return; }
          recording = true; recFinish = finish; mic.classList.add('rec'); t0 = Date.now(); timer = setInterval(tick, 200); tick();
        });
      });
    }
    async function compareVoices(at, url, my) {
      status('⚖️ المقارنة: الأصل ثم صوتك'); showFb('<div class="lx-live">🎧 النطق الأصلي ثم تسجيلك…</div>');
      var ok = await speakP(L[at].de, L[at].spk); if (!ok || my !== tok) return false;
      await wait(250); if (my !== tok) return false;
      var ok2 = await playUrl(url, my); clearFb(); return ok2;
    }
    /* تلقائي: الأصل ← مايك ١٠ ثوانٍ ← مقارنة ← تكرار حتى تضغط الجملة التالية */
    async function runAuto(my) {
      running = true; setBtns();
      while (my === tok) {
        var at = idx; clearFb();
        status('🎧 استمع للجملة'); mic.classList.remove('rec');
        var ok = await speakP(L[at].de, L[at].spk); if (!ok || my !== tok) break;
        var url = await recordWindow(my, REC_MS); if (my !== tok) break;
        if (!url) { status('لم أسمع تسجيلًا… سنعيد المحاولة'); await wait(900); continue; }
        shRec[at] = url;
        if (!(await compareVoices(at, url, my))) break;
        await wait(700);
      }
      if (my === tok) { running = false; setBtns(); }
    }
    function toggleAuto() { if (running) { cancelAll(); status('تم الإيقاف. اضغط ▶ للمتابعة'); } else runAuto(++tok); }
    mic.addEventListener('click', function () {
      if (recording) { if (recFinish) recFinish(); return; }
      if (auto) { toast('في الوضع التلقائي يُفتح المايك بعد النطق الأصلي مباشرة'); return; }
      var my = ++tok; stopSpeak(); clearFb();
      recordWindow(my, 60000).then(async function (url) {
        if (my !== tok) return;
        if (!url) { showFb(errMsg('no-speech')); setBtns(); return; }
        shRec[idx] = url; setBtns();
        await compareVoices(idx, url, my);
      });
    });
    function paint() {
      $$('b', dots).forEach(function (d, i) { d.className = (i === idx ? 'cur ' : '') + (shRec[i] ? 'g' : ''); });
      cnt.textContent = (idx + 1) + ' / ' + L.length;
    }
    function go(i) {
      var wasRunning = running; cancelAll();
      idx = Math.max(0, Math.min(L.length - 1, i)); scroller.innerHTML = '';
      var b = bubble(L[idx], idx); if (hide) b.classList.add('lx-blur');
      if (idx >= L.length - 1) {
        markDone('shadow');
        var nb = ce('button', 'lx-big green lx-cta-next', 'أنهيت الجمل؟ انتقل إلى «دورك» ' + fa('fa-arrow-left')); nb.type = 'button';
        nb.addEventListener('click', function () { cancelAll(); openRole(); }); scroller.appendChild(nb);
      }
      status('الجملة ' + (idx + 1) + ' من ' + L.length + (auto ? ' · اضغط ▶ للبدء' : ' · استمع ثم افتح المايك وتحدّث ثم أغلقه'));
      prev.disabled = idx <= 0; paint(); setBtns();
      if (wasRunning && auto) runAuto(++tok);
    }
    prev.addEventListener('click', function () { go(idx - 1); });
    nxt.addEventListener('click', function () { if (idx >= L.length - 1) { cancelAll(); openRole(); } else go(idx + 1); });
    go(0);
  }

  /* ================= الكلمات (flashcards) — مستقلة عن المحادثة ================= */
  function openCards() {
    var wasBusy = lockTap; stopSpeak(); stopRec(); recStop();
    var deck = WORDS.slice(), idx = 0, kc = 0, known = {};
    cardsOv.style.display = 'flex';
    cardsOv.onclick = function (e) { if (e.target === cardsOv) close(); };
    function artHTML(w) { return w.art ? '<span class="lx-art ' + esc(w.art.toLowerCase()) + '">' + esc(w.art) + '</span>' : ''; }
    function hlEx(w) { var re = new RegExp('(' + w.de.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'i'); return esc(w.ex).replace(re, '<mark>$1</mark>'); }
    function close() { cardsOv.style.display = 'none'; stopSpeak(); if (wasBusy) goStage(curStage); }
    function render() {
      var h = '<div class="lx-box lx-cards-box"><div class="lx-oxbar"><button type="button" class="lx-ox" id="lx-fc-xx" aria-label="إغلاق"><i class="fas fa-xmark"></i></button></div><div class="lx-ctop"><h3>كلمات الدرس <small>(' + WORDS.length + ')</small></h3>' +
        '</div><p class="lx-cnote"><i class="fas fa-pen-fancy"></i> استخدم أداة «كشكولي» من القائمة للكلمات والجمل الصعبة والجديدة.</p>';
      if (!deck.length) {
        h += '<div class="lx-hero" style="box-shadow:none;margin:6px 0"><div class="lx-hi"><i class="fas fa-trophy"></i></div><h2>راجعت كل الكلمات 🎉</h2><p>الخطوة التالية: العب بالكلمات لتثبّتها</p></div><button type="button" class="lx-big green" id="lx-fc-games"><i class="fas fa-gamepad"></i> التالي: لعبة الكلمات</button><button type="button" class="lx-big dark" id="lx-fc-again"><i class="fas fa-rotate-left"></i> مراجعة من جديد</button>';
      } else {
        if (idx >= deck.length) idx = 0;
        var w = deck[idx], q = encodeURIComponent(((w.art ? w.art + ' ' : '') + w.de).trim());
        h += '<div class="lx-pbar"><i style="width:' + Math.round(100 * kc / WORDS.length) + '%"></i></div><div class="lx-count" style="text-align:center">' + (idx + 1) + ' / ' + deck.length + ' · عرفت ' + kc + ' من ' + WORDS.length + '</div>' +
          '<div class="lx-fc"><div class="lx-fc-card" id="lx-fcard">' +
          '<div class="lx-fc-face lx-fc-front">' + artHTML(w) + '<div class="lx-fc-w">' + esc(w.de) + '</div>' +
          '<div class="lx-fc-btns"><button type="button" id="lx-fc-say" aria-label="نطق"><i class="fas fa-volume-high"></i></button>' +
          '<a href="https://www.google.com/search?tbm=isch&q=' + q + '" target="_blank" rel="noopener" id="lx-fc-img" aria-label="صور"><i class="fas fa-image"></i></a></div>' +
          '<span class="lx-fc-hint">اضغط على البطاقة لعرض المعنى</span></div>' +
          '<div class="lx-fc-face lx-fc-back"><div class="lx-fc-ar">' + esc(w.ar || '—') + '</div>' +
          (w.ex ? '<div class="lx-fc-ex" dir="ltr">' + hlEx(w) + '</div><div class="lx-fc-btns"><button type="button" id="lx-fc-sayex" aria-label="نطق الجملة"><i class="fas fa-volume-high"></i></button></div>' : '') + '</div></div></div>' +
          '<div class="lx-cnav"><button type="button" class="lx-arrow" id="lx-fc-pv"><i class="fas fa-chevron-right"></i></button>' +
          '<button type="button" class="lx-big dark" id="lx-fc-ag"><i class="fas fa-rotate-left"></i> أراجعها</button>' +
          '<button type="button" class="lx-big green" id="lx-fc-got"><i class="fas fa-check"></i> عرفتها</button>' +
          '<button type="button" class="lx-arrow" id="lx-fc-nx"><i class="fas fa-chevron-left"></i></button></div>';
      }
      h += '<button type="button" class="lx-x" id="lx-fc-x">رجوع للدرس</button></div>';
      cardsOv.innerHTML = h;
      $('#lx-fc-x', cardsOv).addEventListener('click', close);
      $('#lx-fc-xx', cardsOv).addEventListener('click', close);
      var gb = $('#lx-fc-games', cardsOv); if (gb) gb.addEventListener('click', function () { close(); openGames(); });
      var ag = $('#lx-fc-again', cardsOv); if (ag) { ag.addEventListener('click', function () { deck = WORDS.slice(); idx = 0; kc = 0; known = {}; render(); }); return; }
      var w2 = deck[idx], card = $('#lx-fcard', cardsOv);
      card.addEventListener('click', function () { card.classList.toggle('flip'); });
      $('#lx-fc-say', cardsOv).addEventListener('click', function (e) { e.stopPropagation(); say((w2.art ? w2.art + ' ' : '') + w2.de, 0); });
      $('#lx-fc-img', cardsOv).addEventListener('click', function (e) { e.stopPropagation(); });
      var sx = $('#lx-fc-sayex', cardsOv); if (sx) sx.addEventListener('click', function (e) { e.stopPropagation(); say(w2.ex, 0); });
      $('#lx-fc-got', cardsOv).addEventListener('click', function () { if (!known[w2.de]) { known[w2.de] = 1; kc++; } deck.splice(idx, 1); render(); });
      $('#lx-fc-ag', cardsOv).addEventListener('click', function () { deck.push(deck.splice(idx, 1)[0]); render(); });
      $('#lx-fc-pv', cardsOv).addEventListener('click', function () { idx = (idx - 1 + deck.length) % deck.length; render(); });
      $('#lx-fc-nx', cardsOv).addEventListener('click', function () { idx = (idx + 1) % deck.length; render(); });
    }
    render();
  }
  

  /* ================= المرحلة 3: اختيار الدور (صوتي / كتابة) ================= */
  function goStage(id) { if (id === 'listen') stageListen(); else if (id === 'shadow') stageShadow(); else openRole(); }
  function openRole() {
    curStage = 'role'; reset(); status('اختر دورك لتبدأ');
    scroller.innerHTML = '<div class="lx-hero"><div class="lx-hi"><i class="fas fa-masks-theater"></i></div><h2>دورك في المحادثة</h2><p>الطرف الآخر يتكلم، وفي دورك تردّ بصوتك أو بالكتابة.</p><button type="button" class="lx-cta" id="lx-pick"><i class="fas fa-user-group"></i> اختر دورك</button></div>';
    function draw() {
      roleOv.innerHTML = '<div class="lx-box"><h3>اختر دورك</h3><p>الطرف الآخر يتكلم، وفي دورك يُفتح المايك لتردّ.</p>' +
        '<div class="lx-seg"><button type="button" data-m="voice" class="' + (roleMode === 'voice' ? 'on' : '') + '">🎤 بالصوت</button><button type="button" data-m="write" class="' + (roleMode === 'write' ? 'on' : '') + '">⌨️ كتابةً</button></div>' +
        '<div class="lx-roles">' + [0, 1].map(function (r) { var nm = names[r] || ('Sprecher ' + (r + 1)), c = L.filter(function (l) { return l.spk === r; }).length; return '<button type="button" class="lx-role" data-r="' + r + '"><span class="lx-av s' + r + '">' + esc(nm.charAt(0).toUpperCase()) + '</span>' + esc(nm) + '<small>' + c + ' جمل</small></button>'; }).join('') + '</div>' +
        '<button type="button" class="lx-x" data-k="close">رجوع</button></div>';
      $$('.lx-seg button', roleOv).forEach(function (b) { b.addEventListener('click', function () { roleMode = b.getAttribute('data-m'); draw(); }); });
      $$('[data-r]', roleOv).forEach(function (b) { b.addEventListener('click', function () { startRole(+b.getAttribute('data-r'), roleMode); }); });
      $('[data-k=close]', roleOv).addEventListener('click', function () { roleOv.style.display = 'none'; });
    }
    function show() { draw(); roleOv.style.display = 'flex'; }
    $('#lx-pick', scroller).addEventListener('click', show); show();
  }
  roleOv.addEventListener('click', function (e) { if (e.target === roleOv) roleOv.style.display = 'none'; });

  /* ---------- حلقة الدور ---------- */
  var recs = [], REC_SEC = 10;
  function startRole(r, mode) {
    curStage = 'role'; reset(); lockTap = true; userRole = r; roleMode = mode; recs = [];
    var isV = mode === 'voice', i = 0, score = [], uCount = 0, run = runId, turn;
    status('دورك: ' + (names[r] || '') + (isV ? ' · بالصوت' : ' · كتابةً'));
    subEl.appendChild(linkBtn('إعادة', 'fa-rotate-left', function () { startRole(userRole, mode); }));
    subEl.appendChild(linkBtn('دور آخر', 'fa-right-left', openRole));
    if (isV) { var hb = linkBtn('إخفاء نصّي', 'fa-eye-slash', function () { app.classList.toggle('lx-hide-me'); hb.classList.toggle('on'); }); subEl.appendChild(hb); }
    var pb = ce('div', 'lx-pbar', '<i></i>'); dockEl.appendChild(pb);
    turn = rowEl();

    if (isV) {
      if (!navigator.mediaDevices || !window.MediaRecorder) { scroller.appendChild(ce('div', 'lx-card', '<div class="lx-live">متصفحك لا يدعم التسجيل الصوتي. جرّب Chrome أو Edge.</div>')); return; }
      navigator.mediaDevices.getUserMedia({ audio: true }).then(function (s) {
        if (run !== runId) { s.getTracks().forEach(function (t) { t.stop(); }); return; }
        roleStream = s; step();
      }).catch(function () { scroller.appendChild(ce('div', 'lx-card', '<div class="lx-live">🎤 اسمح باستخدام الميكروفون من إعدادات المتصفح ثم اضغط «إعادة».</div>')); });
    } else step();

    function prog() { $('.lx-pbar i', dockEl).style.width = Math.round(100 * i / L.length) + '%'; }
    async function step() {
      if (run !== runId) return;
      prog();
      if (i >= L.length) return finish();
      var l = L[i];
      turn.innerHTML = '';
      if (l.spk !== r) {
        status(l.name + ' يتحدث…');
        var b = bubble(l, i); hl(b, true);
        var ok = await speakP(l.de, l.spk);
        hl(b, false);
        if (!ok || run !== runId) return;
        i++; await wait(300); step();
      } else {
        if (isV) await voiceTurn(l); else writeTurn(l);
      }
    }
    function next(sc) { score.push(sc); i++; step(); }

    /* دورك بالصوت: المايك يُفتح 10 ثواني تلقائياً ويسجّل رسالتك ثم تكمل المحادثة */
    function voiceTurn(l) {
      return new Promise(function (resolve) {
        var b = bubble(l, i); b.classList.add('me');
        var timer = ce('div', 'lx-timer'); timer.style.setProperty('--p', 100);
        var mic = fab(String(REC_SEC), 'active', function () { finishRec(false); }); mic.style.fontWeight = '900'; mic.setAttribute('aria-label', 'إنهاء التسجيل');
        timer.appendChild(mic);
        turn.appendChild(ic('تخطّي', fa('fa-forward'), '', function () { finishRec(true); }));
        turn.appendChild(timer);
        turn.appendChild(ic('انتهيت', fa('fa-check'), 'green', function () { finishRec(false); }));
        var left = REC_SEC, tm = null, mr = null, chunks = [], idxNow = i, discard = false, ended = false;
        status('دورك — المايك مفتوح، تحدّث الآن 🎤');
        try { mr = new MediaRecorder(roleStream); } catch (e) { mr = null; }
        if (mr) { mr.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); }; mr.onstop = after; mr.start(); }
        tm = setInterval(function () { left--; mic.textContent = Math.max(left, 0); timer.style.setProperty('--p', Math.max(left, 0) * 100 / REC_SEC); if (left <= 0) finishRec(false); }, 1000);
        cancelTurn = function () { discard = true; ended = true; clearInterval(tm); if (mr && mr.state !== 'inactive') { try { mr.onstop = null; mr.stop(); } catch (e) {} } resolve(); };
        function finishRec(skip) {
          if (ended) return; ended = true; discard = !!skip; clearInterval(tm); cancelTurn = null;
          mic.classList.remove('active');
          if (mr && mr.state !== 'inactive') { try { mr.stop(); } catch (e) { after(); } } else after();
        }
        function after() {
          if (run !== runId) { resolve(); return; }
          if (!discard && chunks.length) recs[idxNow] = new Blob(chunks, { type: (mr && mr.mimeType) || 'audio/webm' });
          turn.innerHTML = '';
          resolve();
          i++; wait(400).then(step);
        }
      });
    }

    /* دورك كتابةً: تكتب الكلمة أو الجملة الناقصة، وعند الإجابة الصحيحة تكمل المحادثة تلقائياً */
    function writeTurn(l) {
      status('دورك — اكتب الناقص');
      var pl = plan(l.de, uCount++), b = bubble(l, i); b.classList.add('me', 'force-ar');
      var tx = $('.lx-de', b);
      if (pl.full) {
        var n = l.de.split(/\s+/).length;
        tx.innerHTML = l.ar ? '؟؟؟' : '🎧 اضغط «استمع» ثم اكتب ما سمعته';
        var inp = ce('input', 'lx-in full'); inp.placeholder = 'اكتب الجملة كاملة بالألمانية… (' + n + ' كلمات)';
        inp.setAttribute('data-a', l.de); inp.autocomplete = 'off'; inp.autocapitalize = 'off'; inp.spellcheck = false;
        tx.insertAdjacentElement('afterend', inp);
      } else {
        tx.innerHTML = pl.tokens.map(function (w) {
          if (!w.blank) return esc(w.o);
          var pre = w.o.slice(0, w.o.indexOf(w.core)), post = w.o.slice(w.o.indexOf(w.core) + w.core.length);
          return esc(pre) + '<input class="lx-in" data-a="' + esc(w.core) + '" size="' + Math.max(5, w.core.length) + '" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="؟"/>' + esc(post);
        }).join(' ');
      }
      var ins = $$('.lx-in', b), hints = 0, finished = false, timer = null;
      if (ins[0]) ins[0].focus({ preventScroll: true });
      turn.appendChild(ic('استمع', fa('fa-volume-high'), '', function () { say(l.de, l.spk); }));
      turn.appendChild(ic('تلميح', fa('fa-lightbulb'), '', function () {
        var t = ins.filter(function (x) { return !x.disabled; })[0]; if (!t) return;
        hints++; var a = t.getAttribute('data-a'); t.value = a.slice(0, Math.min(a.length - 1, hints)); t.focus();
      }));
      turn.appendChild(ic('تحقّق', fa('fa-check'), 'pri', check));
      turn.appendChild(ic('تخطّي', fa('fa-forward'), '', function () { if (run === runId && !finished) { finished = true; next(0); } }));
      ins.forEach(function (x) {
        x.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); check(); } });
        x.addEventListener('input', function () {
          if (finished) return;
          if (ins.every(function (y) { return nrm(y.value) === nrm(y.getAttribute('data-a')); })) check();
        });
      });
      function go(sc, ms) {
        turn.innerHTML = '';
        turn.appendChild(ic('متابعة', fa('fa-chevron-left'), 'pri', function () { clearTimeout(timer); if (run === runId) next(sc); }));
        timer = setTimeout(function () { if (run === runId) next(sc); }, ms);
        cancelTurn = function () { clearTimeout(timer); };
      }
      function check() {
        if (finished) return; finished = true;
        var tot = 0, ok = 0;
        ins.forEach(function (x) {
          var a = x.getAttribute('data-a'), v = x.value, rr;
          if (x.classList.contains('full')) { var c = compare(a, v).pct; rr = c >= 90 ? 1 : c >= 70 ? 0.5 : 0; }
          else { var n1 = nrm(v), n2 = nrm(a); rr = n1 === n2 ? 1 : (n1 && lev(n1, n2) <= 1) ? 0.5 : 0; }
          x.disabled = true; x.classList.add(rr === 1 ? 'ok' : rr ? 'near' : 'bad');
          if (rr < 1) x.insertAdjacentElement('afterend', ce('span', 'lx-ans', esc(a)));
          tot++; ok += rr;
        });
        var sc = Math.max(0, Math.round(100 * ok / tot) - hints * 8);
        var msg = sc >= 90 ? '✅ ممتاز! إجابة صحيحة' : sc >= 50 ? '👍 قريب جداً — راجع الصحيح بالأخضر' : '❌ الإجابة الصحيحة ظاهرة أمامك';
        if (pl.full) tx.textContent = l.de;
        b.appendChild(ce('div', 'lx-note', msg));
        toBottom(); say(l.de, l.spk);
        go(sc, sc >= 90 ? 1800 : 4200);
      }
    }

    function finish() {
      closeStream(); lockTap = false; markDone('role');
      var scs = score.length ? Math.round(score.reduce(function (a, b) { return a + b; }, 0) / score.length) : 0;
      status('انتهت المحادثة 🎉'); turn.innerHTML = '';
      var cls = scs >= 85 ? 'lx-g' : scs >= 60 ? 'lx-y' : 'lx-r';
      var hasRec = isV && recs.some(function (u) { return !!u; });
      var head = isV ? '<h3>أنهيت المحادثة 🎉</h3><p>سجّلت ' + recs.filter(Boolean).length + ' من ردودك</p>' :
        '<div class="' + cls + '" style="display:flex;justify-content:center;margin-bottom:8px"><div class="lx-ring" style="--p:' + scs + '"><b>' + scs + '%</b></div></div><h3>' + (scs >= 85 ? 'أداء رائع! 🎉' : scs >= 60 ? 'أداء جيد 👏' : 'تحتاج مزيداً من التدريب 💪') + '</h3><p>انتهى الحوار — هذه نتيجتك التقريبية</p>';
      endOv.innerHTML = '<div class="lx-box">' + head +
        '<button type="button" class="lx-big green" data-a="next"><i class="fas fa-arrow-left"></i> ' + (WORDS.length ? 'التالي: مراجعة الكلمات' : 'التالي: لعبة الكلمات') + '</button>' +
        (hasRec ? '<button type="button" class="lx-big green" data-a="mix"><i class="fas fa-headphones"></i> اسمع المحادثة بصوتك</button>' : '') +
        '<button type="button" class="lx-big" data-a="re"><i class="fas fa-rotate-left"></i> أعد المحاولة</button>' +
        '<button type="button" class="lx-big dark" data-a="oth"><i class="fas fa-right-left"></i> الدور الآخر</button>' +
        '<button type="button" class="lx-big dark" data-a="mode">' + (isV ? '⌨️ جرّب الكتابة' : '🎤 جرّب الصوت') + '</button>' +
        '<button type="button" class="lx-x" data-a="x">إغلاق</button></div>';
      endOv.style.display = 'flex';
      var act = function (a, fn) { var e = $('[data-a=' + a + ']', endOv); if (e) e.addEventListener('click', fn); };
      act('re', function () { startRole(r, mode); });
      act('oth', function () { startRole(r === 0 ? 1 : 0, mode); });
      act('mode', function () { startRole(r, isV ? 'write' : 'voice'); });
      act('next', function () { endOv.style.display = 'none'; WORDS.length ? openCards() : openGames(); });
      act('x', function () { endOv.style.display = 'none'; });
      act('mix', function () { endOv.style.display = 'none'; playMix(); });
    }
  }

  /* ---------- المحادثة كاملة: ردودك المسجّلة + صوت الطرف الآخر ---------- */
  async function playMix() {
    curStage = 'role'; reset(); lockTap = true; status('المحادثة كاملة بصوتك 🎧');
    var run = runId, cur = null, r = rowEl();
    r.appendChild(fab(fa('fa-stop'), '', function () { runId++; stopSpeak(); if (cur) cur.pause(); openRole(); }));
    for (var i = 0; i < L.length; i++) {
      if (run !== runId) return;
      var b = bubble(L[i], i); hl(b, true);
      if (L[i].spk === userRole && recs[i]) {
        var a = new Audio(URL.createObjectURL(recs[i])); cur = a;
        await new Promise(function (res) { a.onended = res; a.onerror = res; var p = a.play(); if (p && p.catch) p.catch(res); });
      } else { var ok = await speakP(L[i].de, L[i].spk); if (!ok) return; }
      hl(b, false); await wait(300);
    }
    if (run === runId) { lockTap = false; dockEl.innerHTML = ''; var r2 = rowEl(); var bb = ce('button', 'lx-cta', fa('fa-arrow-left') + ' رجوع للأدوار'); bb.type = 'button'; bb.addEventListener('click', openRole); r2.appendChild(bb); }
  }

  /* ================= شاشة البدء + قائمة العرض + الألعاب ================= */
  function setView(m) { viewMode = m; LS.set('lx_view', m); app.classList.toggle('lx-view-scene', m === 'scene'); }
  function api() {
    return { WORDS: WORDS, L: L, title: title, names: names, wTxt: wTxt, esc: esc, app: app, toast: toast,
      speak: function (text, spk, rate) { var o = speed; if (rate) speed = rate; return speakP(text, spk || 0).then(function (r) { speed = o; return r; }); },
      stop: stopSpeak, prefetch: function (text, spk) { if (PIPER.on && PIPER.state === 'ready') { try { return pSynth(text, spk || 0).catch(function () {}); } catch (e) {} } return Promise.resolve(); },
      listen: listen, stopRec: stopRec, compare: compare, nrm: nrm, lev: lev, SR: !!SR, errMsg: errMsg,
      lang: function () { return 'de-DE'; }, endLesson: showFinish };
  }
  window.LXAPI = api;
  function openGames() {
    stopSpeak();
    if (window.LXGames) { window.LXGames.open(api()); return; }
    var s = document.createElement('script'); s.src = '/assets/games.js';
    s.onload = function () { window.LXGames.open(api()); };
    s.onerror = function () { toast('تعذّر تحميل الألعاب. تحقّق من الاتصال.'); };
    document.head.appendChild(s);
  }
  /* ---------- نهاية الدرس: العودة للمكتبة أو الاستماع من جديد ---------- */
  function showFinish() {
    stopSpeak(); recStop();
    endOv.innerHTML = '<div class="lx-box"><div class="lx-hero" style="box-shadow:none;margin:0 0 6px"><div class="lx-hi"><i class="fas fa-trophy"></i></div><h2>أنهيت الدرس! 🎉</h2><p>أحسنت، أكملت كل الخطوات: استمعت وقلّدت ولعبت دورك وراجعت الكلمات ولعبت بها.</p></div>' +
      '<a class="lx-big green" href="' + esc(libHref) + '"><i class="fas fa-book-open"></i> إنهاء الدرس والعودة إلى المكتبة</a>' +
      '<button type="button" class="lx-big dark" data-a="again"><i class="fas fa-rotate-left"></i> إعادة الدرس من الاستماع</button>' +
      '<button type="button" class="lx-x" data-a="x">إغلاق</button></div>';
    endOv.style.display = 'flex';
    var again = $('[data-a=again]', endOv), x = $('[data-a=x]', endOv);
    if (again) again.addEventListener('click', function () { endOv.style.display = 'none'; var g = document.querySelector('.gm-ov'); if (g) g.remove(); done = {}; stageListen(); });
    if (x) x.addEventListener('click', function () { endOv.style.display = 'none'; });
  }
  function openView(kind) {
    closeMenus(); launch.classList.remove('on');
    if (kind === 'chat' || kind === 'scene') { setView(kind); if (curStage !== 'listen') stageListen(); else if (kind === 'chat') toBottom(); }
    else if (kind === 'words') { if (WORDS.length) openCards(); }
    else if (kind === 'games') openGames();
  }
  $$('button', vm).forEach(function (b) { b.addEventListener('click', function () { openView(b.getAttribute('data-v')); }); });
  $$('.lx-lt', launch).forEach(function (b) { b.addEventListener('click', function () { openView(b.getAttribute('data-l')); }); });

  /* ---------- تشغيل ---------- */
  piperInit();
  stageListen();
  launch.classList.add('on');
})();
