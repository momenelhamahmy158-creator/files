/* ================================================================
   Sprich — ألعاب الكلمات (على طريقة دولينجو)
   تُحمَّل عند الحاجة من صفحة الدرس: LXGames.open(LXAPI())
   بيانات اللعبة: كلمات الدرس (WORDS) وجمل الحوار (L).
   ================================================================ */
(function () {
  'use strict';
  var LS = { get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };
  var A = null, root = null, st = null, sfxOn = LS.get('lx_sfx') !== '0';

  /* ---------------- أدوات ---------------- */
  function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function cyc(arr, n) { var out = [], pool = []; while (out.length < n && arr.length) { if (!pool.length) pool = shuffle(arr); out.push(pool.pop()); } return out; }
  function rnd(a) { return a[Math.floor(Math.random() * a.length)]; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  /* توحيد الكتابة الألمانية: ä=a=ae ، ö=o=oe ، ü=u=ue ، ß=ss وتجاهل الحالة والرموز */
  function dn(s) { return String(s || '').toLowerCase().replace(/ß/g, 'ss').replace(/ä/g, 'a').replace(/ö/g, 'o').replace(/ü/g, 'u').replace(/ae/g, 'a').replace(/oe/g, 'o').replace(/ue/g, 'u').replace(/[^a-z0-9]/g, ''); }
  function stripArt(s) { return String(s || '').replace(/^(der|die|das)\s+/i, ''); }
  function wLabel(w) { return (w.art ? w.art + ' ' : '') + w.de; }
  function words() { return A.WORDS.filter(function (w) { return w.de; }); }
  function sents() { return A.L.filter(function (l) { return l.de && l.ar; }); }
  var STOP = /^(der|die|das|ein|eine|einen|einem|einer|und|oder|ist|sind|bin|bist|ich|du|er|sie|es|wir|ihr|zu|in|im|am|an|auf|mit|von|für|den|dem|des|nicht|ja|nein|bitte|danke|hier|dort|auch|aber|dass|wie|was|wo|wer|mir|dir)$/i;
  function rawToks(s) { return String(s).split(/\s+/).filter(Boolean); }
  function core(t) { return t.replace(/^[^A-Za-zÄÖÜäöüß]+|[^A-Za-zÄÖÜäöüß]+$/g, ''); }
  function candidates(s) { var out = []; rawToks(s).forEach(function (t, i) { var c = core(t); if (c.length >= 4 && !STOP.test(c) && /^[A-Za-zÄÖÜäöüß]+$/.test(c)) out.push(i); }); return out; }
  function tokCount(s) { return rawToks(s).length; }

  /* ---------------- أصوات وتشجيع ---------------- */
  var AC = null;
  function actx() { if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} } if (AC && AC.state === 'suspended') { try { AC.resume(); } catch (e) {} } return AC; }
  function tone(f, d, type, vol, t0) {
    if (!sfxOn) return; var c = actx(); if (!c) return;
    var o = c.createOscillator(), g = c.createGain(), t = c.currentTime + (t0 || 0);
    o.type = type || 'sine'; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.2, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + d + 0.05);
  }
  var SFX = {
    tap: function () { tone(660, 0.06, 'triangle', 0.12); },
    pair: function () { tone(880, 0.1, 'sine', 0.2); tone(1318, 0.16, 'sine', 0.2, 0.08); },
    ok: function () { tone(784, 0.12, 'triangle', 0.22); tone(1047, 0.24, 'triangle', 0.22, 0.1); },
    bad: function () { tone(220, 0.18, 'sawtooth', 0.16); tone(165, 0.3, 'sawtooth', 0.16, 0.14); },
    streak: function () { [784, 988, 1175, 1568].forEach(function (f, i) { tone(f, 0.14, 'triangle', 0.2, i * 0.07); }); },
    win: function () { [523, 659, 784, 1047, 784, 1047, 1319].forEach(function (f, i) { tone(f, 0.2, 'triangle', 0.22, i * 0.11); }); },
    lose: function () { [392, 330, 262, 196].forEach(function (f, i) { tone(f, 0.28, 'sawtooth', 0.15, i * 0.18); }); }
  };
  function buzz(p) { try { if (navigator.vibrate) navigator.vibrate(p); } catch (e) {} }
  var PRAISE = ['ممتاز! 🔥', 'رائع جدًا! 🎉', 'أحسنت! 👏', 'إجابة صحيحة! ✅', 'عبقري! 🧠', 'استمر هكذا! 💪', 'يا سلام! ⭐', 'مذهل! 🚀'];
  var OOPS = ['ليس تمامًا… ركّز! 💡', 'قريب! لا تستسلم 💪', 'الخطأ يعلّمنا 🌱', 'سنراجعها لاحقًا ✨'];
  var STREAKS = { 3: '🔥 ٣ متتالية! أنت مشتعل', 5: '⚡ ٥ متتالية! لا يوقفك أحد', 8: '👑 ٨ متتالية! أسطورة' };
  function confetti() {
    var cv = document.createElement('canvas'); cv.className = 'gm-conf'; root.appendChild(cv);
    var w = cv.width = root.clientWidth, h = cv.height = root.clientHeight, x = cv.getContext('2d'), cols = ['#dc143c', '#ff7a45', '#ffb703', '#58cc02', '#1cb0f6', '#a560e8'], ps = [], i;
    for (i = 0; i < 150; i++) ps.push({ x: w / 2 + (Math.random() - .5) * 80, y: h * .38, vx: (Math.random() - .5) * 14, vy: -Math.random() * 14 - 4, s: 5 + Math.random() * 6, c: cols[i % cols.length], r: Math.random() * 6, vr: (Math.random() - .5) * .4 });
    var t0 = Date.now();
    (function frame() {
      x.clearRect(0, 0, w, h); var age = Date.now() - t0;
      ps.forEach(function (p) { p.vy += .35; p.x += p.vx; p.y += p.vy; p.r += p.vr; x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c; x.globalAlpha = Math.max(0, 1 - age / 2400); x.fillRect(-p.s / 2, -p.s / 3, p.s, p.s * .66); x.restore(); });
      if (age < 2400) requestAnimationFrame(frame); else cv.remove();
    })();
  }

  /* ---------------- الستايل ---------------- */
  var CSS = '' +
    '.gm-ov{position:absolute;inset:0;z-index:45;background:var(--bg,#fbf7f3);color:var(--ink,#17141f);display:flex;flex-direction:column;direction:rtl;font-family:inherit;overflow:hidden}' +
    '.gm-ov button{font-family:inherit}' +
    '.gm-top{display:flex;align-items:center;gap:10px;padding:calc(12px + env(safe-area-inset-top)) 14px 10px;flex:none}' +
    '.gm-x{width:42px;height:42px;border-radius:50%;background:var(--soft,#f4efea);display:grid;place-items:center;border:0;color:var(--ink);cursor:pointer;flex:none;box-shadow:none;padding:0;font-size:16px}' +
    '.gm-bar{flex:1;height:14px;background:var(--soft,#eee);border-radius:10px;overflow:hidden}' +
    '.gm-bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#58cc02,#89e219);border-radius:10px;transition:width .4s}' +
    '.gm-hearts{font-weight:900;color:#ff4b4b;display:flex;align-items:center;gap:5px;flex:none;font-size:1.05rem}' +
    '.gm-body{flex:1;overflow:auto;padding:6px 18px 18px;display:flex;flex-direction:column;align-items:center;-webkit-overflow-scrolling:touch}' +
    '.gm-box{width:100%;max-width:560px;margin:auto 0}' +
    '.gm-box h3{font-size:1.25rem;font-weight:900;margin:6px 0 16px;text-align:center}' +
    '.gm-word{font-size:clamp(1.9rem,8vw,2.8rem);font-weight:900;text-align:center;margin:8px 0;direction:ltr}' +
    '.gm-mean{text-align:center;color:var(--mute,#777);font-weight:800;font-size:1.05rem;margin-bottom:10px}' +
    '.gm-sent{text-align:center;font-size:1.3rem;font-weight:800;line-height:1.9;margin:8px 0 14px}' +
    '.gm-sent.de{direction:ltr}' +
    '.gm-audio{display:flex;gap:12px;justify-content:center;margin:8px 0 14px}' +
    '.gm-spk{width:68px;height:68px;border-radius:50%;border:0;background:linear-gradient(135deg,#1cb0f6,#1899d6);color:#fff;font-size:26px;display:grid;place-items:center;cursor:pointer;box-shadow:0 5px 0 #1479a9;padding:0}' +
    '.gm-spk.slow{width:50px;height:50px;font-size:18px;background:linear-gradient(135deg,#a560e8,#8549ba);box-shadow:0 4px 0 #6a3a94;align-self:center}' +
    '.gm-spk:active{transform:translateY(3px);box-shadow:none}' +
    '.gm-in{width:100%;padding:15px 16px;border-radius:16px;border:2px solid var(--line,#e5e5e5);background:var(--card,#fff);color:var(--ink);font:800 1.25rem inherit;font-family:inherit;direction:ltr;text-align:left;outline:none;margin:6px 0}' +
    '.gm-in:focus{border-color:#1cb0f6}' +
    '.gm-in.sm{display:inline-block;width:8.5ch;min-width:5ch;max-width:100%;padding:4px 8px;margin:0 4px;font-size:1.15rem;text-align:center;border-radius:10px;border-style:dashed}' +
    '.gm-in.one{width:84px;text-align:center;font-size:2rem;display:block;margin:12px auto}' +
    '.gm-keys{display:flex;gap:8px;justify-content:center;margin:8px 0}' +
    '.gm-keys button{min-width:48px;height:44px;border-radius:12px;border:2px solid var(--line,#e5e5e5);background:var(--card,#fff);color:var(--ink);font-weight:900;font-size:1.1rem;cursor:pointer;box-shadow:0 3px 0 var(--line,#e5e5e5)}' +
    '.gm-opts{display:grid;gap:10px;margin:8px 0}' +
    '.gm-opt{width:100%;padding:15px 16px;border-radius:16px;border:2px solid var(--line,#e5e5e5);background:var(--card,#fff);color:var(--ink);font-weight:800;font-size:1.05rem;cursor:pointer;box-shadow:0 4px 0 var(--line,#e5e5e5);text-align:center;line-height:1.7}' +
    '.gm-opt:active{transform:translateY(3px);box-shadow:none}' +
    '.gm-opt.sel{border-color:#1cb0f6;background:rgba(28,176,246,.1);box-shadow:0 4px 0 #1cb0f6}' +
    '.gm-opt.ltr{direction:ltr}' +
    '.gm-art{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:14px}' +
    '.gm-art .gm-opt{font-size:1.5rem;font-weight:900;padding:18px 6px}' +
    '.gm-art .gm-opt[data-a=der].sel{border-color:#1cb0f6;box-shadow:0 4px 0 #1cb0f6;background:rgba(28,176,246,.12)}' +
    '.gm-art .gm-opt[data-a=die].sel{border-color:#ff4b4b;box-shadow:0 4px 0 #ff4b4b;background:rgba(255,75,75,.1)}' +
    '.gm-art .gm-opt[data-a=das].sel{border-color:#58cc02;box-shadow:0 4px 0 #58cc02;background:rgba(88,204,2,.1)}' +
    '.gm-mic{display:grid;place-items:center;width:92px;height:92px;border-radius:50%;margin:14px auto;border:0;background:linear-gradient(135deg,#dc143c,#ff5a5f);color:#fff;font-size:34px;cursor:pointer;box-shadow:0 6px 0 #9d0e2a;padding:0}' +
    '.gm-mic.on{animation:gmPulse 1s infinite}' +
    '@keyframes gmPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.1)}}' +
    '.gm-say{min-height:26px;text-align:center;font-weight:800;direction:ltr;color:var(--mute,#777);margin:4px 0}' +
    '.gm-skip{display:block;margin:10px auto 0;background:none;border:0;color:var(--mute,#888);font-weight:800;text-decoration:underline;cursor:pointer;box-shadow:none;font-size:.9rem}' +
    '.gm-self{display:flex;gap:10px;justify-content:center;margin-top:8px}' +
    '.gm-ord{min-height:64px;border-bottom:2px dashed var(--line,#ccc);display:flex;flex-wrap:wrap;gap:8px;padding:6px 0 10px;direction:ltr;align-items:center;margin-bottom:16px}' +
    '.gm-bank{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;direction:ltr}' +
    '.gm-tile{padding:11px 15px;border-radius:14px;border:2px solid var(--line,#e5e5e5);background:var(--card,#fff);color:var(--ink);font-weight:800;font-size:1.05rem;cursor:pointer;box-shadow:0 4px 0 var(--line,#e5e5e5)}' +
    '.gm-tile.used{opacity:.25;pointer-events:none}' +
    '.gm-match{display:grid;grid-template-columns:1fr 1fr;gap:10px}' +
    '.gm-match .gm-opt{padding:14px 8px;font-size:1rem}' +
    '.gm-opt.done{background:rgba(88,204,2,.14);border-color:#58cc02;box-shadow:none;color:#3f9400;pointer-events:none;opacity:.7}' +
    '.gm-opt.shake{animation:gmShake .35s;border-color:#ff4b4b}' +
    '@keyframes gmShake{0%,100%{transform:translateX(0)}25%{transform:translateX(-7px)}75%{transform:translateX(7px)}}' +
    '.gm-mem{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}' +
    '.gm-card2{aspect-ratio:1/1.05;border-radius:16px;border:0;background:linear-gradient(135deg,#8b5cf6,#4f46e5);color:transparent;font-weight:900;font-size:.98rem;cursor:pointer;padding:6px;line-height:1.4;display:grid;place-items:center;box-shadow:0 4px 0 #3730a3;transition:transform .2s}' +
    '.gm-card2.up{background:var(--card,#fff);color:var(--ink);box-shadow:0 4px 0 var(--line,#e5e5e5);border:2px solid #8b5cf6}' +
    '.gm-card2.done{background:rgba(88,204,2,.14);color:#3f9400;border:2px solid #58cc02;box-shadow:none;pointer-events:none}' +
    '.gm-foot{flex:none;padding:12px 16px calc(14px + env(safe-area-inset-bottom));border-top:2px solid var(--line,#eee);background:var(--bg,#fbf7f3);display:flex;flex-direction:column;align-items:center;gap:10px;transition:background .25s}' +
    '.gm-foot.ok{background:#d7ffb8;border-color:#b8f28a;color:#3f7d00}' +
    '.gm-foot.bad{background:#ffdfe0;border-color:#ffc1c3;color:#b3202b}' +
    'html[data-theme=dark] .gm-foot.ok{background:#1f3a14;color:#b8f28a;border-color:#2c5a1b}' +
    'html[data-theme=dark] .gm-foot.bad{background:#3d1a1d;color:#ffb3b6;border-color:#5a2a2e}' +
    '.gm-fb{width:100%;max-width:560px;font-weight:900;line-height:1.7}' +
    '.gm-fb b{display:block;font-size:1.1rem}' +
    '.gm-fb small{display:block;font-weight:800;opacity:.9;font-size:.92rem}' +
    '.gm-fb .de{direction:ltr;display:inline-block}' +
    '.gm-chk{width:100%;max-width:560px;height:54px;border-radius:16px;border:0;background:#58cc02;color:#fff;font-weight:900;font-size:1.1rem;cursor:pointer;box-shadow:0 5px 0 #46a302}' +
    '.gm-chk:disabled{background:var(--soft,#e5e5e5);color:#afafaf;box-shadow:0 5px 0 #d0d0d0;cursor:not-allowed}' +
    '.gm-chk:active:not(:disabled){transform:translateY(4px);box-shadow:none}' +
    '.gm-foot.bad .gm-chk{background:#ff4b4b;box-shadow:0 5px 0 #d33131}' +
    '.gm-hub{flex:1;overflow:auto;padding:4px 16px 26px;-webkit-overflow-scrolling:touch}' +
    '.gm-hh{display:flex;align-items:center;gap:10px;padding:calc(12px + env(safe-area-inset-top)) 14px 8px;flex:none}' +
    '.gm-hh h2{flex:1;font-size:1.25rem;font-weight:900}' +
    '.gm-chips{display:flex;gap:8px;flex-wrap:wrap;margin:4px 0 14px}' +
    '.gm-chip{background:var(--soft,#f4efea);border-radius:99px;padding:6px 13px;font-weight:800;font-size:.85rem}' +
    '.gm-mix{width:100%;border:0;border-radius:24px;padding:20px 18px;color:#fff;text-align:right;display:flex;align-items:center;gap:14px;cursor:pointer;background:linear-gradient(135deg,#58cc02,#2fa300);box-shadow:0 6px 0 #247f00;margin-bottom:18px}' +
    '.gm-mix i{font-size:2.2rem}.gm-mix b{display:block;font-size:1.2rem;font-weight:900}.gm-mix small{opacity:.92;font-weight:700}' +
    '.gm-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}' +
    '.gm-g{border:2px solid var(--line,#eee);background:var(--card,#fff);color:var(--ink);border-radius:22px;padding:16px 10px;text-align:center;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:6px;box-shadow:0 4px 0 var(--line,#eee)}' +
    '.gm-g:active{transform:translateY(3px);box-shadow:none}' +
    '.gm-g:disabled{opacity:.45;cursor:not-allowed}' +
    '.gm-gi{width:58px;height:58px;border-radius:18px;display:grid;place-items:center;color:#fff;font-size:24px}' +
    '.gm-g b{font-size:.98rem;font-weight:900;line-height:1.4}' +
    '.gm-g small{font-size:.76rem;color:var(--mute,#777);font-weight:700;line-height:1.5}' +
    '.gm-stars{color:#ffb703;letter-spacing:2px;font-size:.9rem;min-height:1.1rem}' +
    '.gm-res{text-align:center;max-width:460px;margin:auto}' +
    '.gm-res .big{font-size:4.2rem;margin-bottom:6px}' +
    '.gm-res h2{font-size:1.6rem;font-weight:900;margin-bottom:6px}' +
    '.gm-res p{color:var(--mute);font-weight:700;margin-bottom:14px}' +
    '.gm-rstats{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:14px 0 18px}' +
    '.gm-rstats div{background:var(--soft,#f4efea);border-radius:18px;padding:12px 6px;font-weight:800;font-size:.8rem;color:var(--mute)}' +
    '.gm-rstats b{display:block;font-size:1.4rem;color:var(--ink)}' +
    '.gm-rbtn{display:block;width:100%;margin:8px 0;padding:15px;border-radius:16px;border:0;background:#58cc02;color:#fff;font-weight:900;font-size:1.05rem;cursor:pointer;box-shadow:0 5px 0 #46a302}' +
    '.gm-rbtn.alt{background:var(--soft,#e5e5e5);color:var(--ink);box-shadow:0 5px 0 var(--line,#d0d0d0)}' +
    '.gm-conf{position:absolute;inset:0;pointer-events:none;z-index:60}' +
    '.gm-toast{position:absolute;top:calc(70px + env(safe-area-inset-top));left:50%;transform:translateX(-50%);background:#17141f;color:#fff;font-weight:900;padding:10px 20px;border-radius:30px;z-index:70;animation:gmToast 1.8s both;white-space:nowrap}' +
    '@keyframes gmToast{0%{opacity:0;transform:translate(-50%,-10px)}12%,80%{opacity:1;transform:translate(-50%,0)}100%{opacity:0}}';

  /* ---------------- كتالوج الألعاب ---------------- */
  var GAMES = [
    { id: 'listenType', t: 'استمع واكتب', d: 'تسمع الكلمة وتكتبها', i: 'fa-keyboard', c: 'linear-gradient(135deg,#1cb0f6,#1479a9)' },
    { id: 'speak', t: 'انطق الكلمة', d: 'ترى الكلمة وتنطقها بصوتك', i: 'fa-microphone', c: 'linear-gradient(135deg,#dc143c,#ff5a5f)' },
    { id: 'translate', t: 'ترجمة الجمل', d: 'عربي ← ألماني وألماني ← عربي', i: 'fa-language', c: 'linear-gradient(135deg,#a560e8,#7a3fc0)' },
    { id: 'cloze', t: 'أكمل بالصوت', d: 'جملة ينقصها كلمة، اسمعها وأكملها', i: 'fa-ear-listen', c: 'linear-gradient(135deg,#0d9488,#22c55e)' },
    { id: 'match', t: 'وصّل بمعناها', d: 'وصّل كل كلمة بمعناها', i: 'fa-link', c: 'linear-gradient(135deg,#f59e0b,#ff6a3d)' },
    { id: 'order', t: 'رتّب الجملة', d: 'رتّب كلمات الجملة المبعثرة', i: 'fa-shuffle', c: 'linear-gradient(135deg,#ec4899,#be185d)' },
    { id: 'letter', t: 'الحرف الناقص', d: 'اكتب الحرف الناقص في الكلمة', i: 'fa-spell-check', c: 'linear-gradient(135deg,#6366f1,#4338ca)' },
    { id: 'article', t: 'der · die · das', d: 'اختر أداة التعريف الصحيحة', i: 'fa-tags', c: 'linear-gradient(135deg,#14b8a6,#0f766e)' },
    { id: 'pickMeaning', t: 'اختر الإجابة', d: 'اختر المعنى أو الكلمة من الصوت', i: 'fa-circle-check', c: 'linear-gradient(135deg,#84cc16,#4d7c0f)' },
    { id: 'memory', t: 'لعبة الذاكرة', d: 'اقلب البطاقات وطابق الأزواج', i: 'fa-clone', c: 'linear-gradient(135deg,#8b5cf6,#4f46e5)' }
  ];
  var NEED = {
    listenType: 'يحتاج كلمات', speak: 'يحتاج كلمات', match: 'يحتاج ٣ كلمات على الأقل', memory: 'يحتاج ٣ كلمات على الأقل', pickMeaning: 'يحتاج ٣ كلمات على الأقل',
    article: 'يحتاج كلمتين بأداة تعريف', letter: 'يحتاج كلمات أطول', translate: 'يحتاج ٣ جمل مترجمة', cloze: 'لا توجد جمل مناسبة', order: 'لا توجد جمل مناسبة'
  };
  function canPlay(id) {
    var W = words(), S = sents();
    switch (id) {
      case 'listenType': case 'speak': return W.length >= 1;
      case 'match': case 'memory': case 'pickMeaning': return W.length >= 3;
      case 'article': return W.filter(function (w) { return /^(der|die|das)$/i.test(w.art || ''); }).length >= 2;
      case 'letter': return W.some(function (w) { return stripArt(w.de).length >= 4; });
      case 'translate': return S.length >= 3;
      case 'cloze': return S.some(function (s) { return candidates(s.de).length; });
      case 'order': return S.some(function (s) { var n = tokCount(s.de); return n >= 3 && n <= 10; });
    }
    return true;
  }
  function optsAr(s) { var others = sents().filter(function (x) { return x !== s && x.ar !== s.ar; }); return shuffle([s.ar].concat(shuffle(others).slice(0, 3).map(function (x) { return x.ar; }))); }
  function optsW(w, key) { var others = words().filter(function (x) { return x !== w && x[key] !== w[key]; }); return shuffle([w].concat(shuffle(others).slice(0, 3))); }
  var COUNTS = { listenType: 8, speak: 6, translate: 8, cloze: 8, match: 3, order: 7, letter: 8, article: 8, pickMeaning: 8, memory: 1 };
  var GEN = {
    listenType: function (n) { return cyc(words(), n).map(function (w) { return { type: 'listenType', w: w }; }); },
    speak: function (n) { return cyc(words(), n).map(function (w) { return { type: 'speak', w: w }; }); },
    translate: function (n) { return cyc(sents(), n).map(function (s, i) { return i % 2 === 0 ? { type: 'trAr2De', s: s } : { type: 'trDe2Ar', s: s, opts: optsAr(s) }; }); },
    cloze: function (n) { return cyc(sents().filter(function (s) { return candidates(s.de).length; }), n).map(function (s) { return { type: 'cloze', s: s, idx: rnd(candidates(s.de)) }; }); },
    match: function (n) { var W = words(); return Array.apply(null, Array(n)).map(function () { return { type: 'match', pairs: shuffle(W).slice(0, Math.min(5, W.length)) }; }); },
    order: function (n) { return cyc(sents().filter(function (s) { var k = tokCount(s.de); return k >= 3 && k <= 10; }), n).map(function (s) { return { type: 'order', s: s }; }); },
    letter: function (n) {
      return cyc(words().filter(function (w) { return stripArt(w.de).length >= 4; }), n).map(function (w) {
        var word = stripArt(w.de), pos = [], i; for (i = 0; i < word.length; i++) if (/[A-Za-zÄÖÜäöüß]/.test(word[i])) pos.push(i);
        return { type: 'letter', w: w, word: word, pos: rnd(pos) };
      });
    },
    article: function (n) { return cyc(words().filter(function (w) { return /^(der|die|das)$/i.test(w.art || ''); }), n).map(function (w) { return { type: 'article', w: w }; }); },
    pickMeaning: function (n) { return cyc(words(), n).map(function (w, i) { return i % 2 === 0 ? { type: 'pickMeaning', w: w, opts: optsW(w, 'ar') } : { type: 'listenPick', w: w, opts: optsW(w, 'de') }; }); },
    memory: function () { return [{ type: 'memory', pairs: shuffle(words()).slice(0, Math.min(6, words().length)) }]; }
  };
  function buildQueue(id) {
    if (id !== 'mix') return GEN[id](COUNTS[id]);
    var pool = [], ids = GAMES.map(function (g) { return g.id; }).filter(function (x) { return x !== 'memory' && canPlay(x); });
    ids.forEach(function (g) { var n = g === 'match' ? 1 : g === 'speak' ? 1 : 2; pool = pool.concat(GEN[g](n)); });
    return shuffle(pool).slice(0, 10);
  }

  /* ---------------- مكوّنات الواجهة ---------------- */
  function audioBtns(slow) { return '<div class="gm-audio"><button type="button" class="gm-spk" data-sp="1" aria-label="استمع"><i class="fas fa-volume-high"></i></button>' + (slow !== false ? '<button type="button" class="gm-spk slow" data-sp="0.6" aria-label="ببطء"><i class="fas fa-snail"></i></button>' : '') + '</div>'; }
  function wireAudio(box, text, spk) {
    [].forEach.call(box.querySelectorAll('[data-sp]'), function (b) { b.onclick = function () { SFX.tap(); A.speak(text, spk, +b.getAttribute('data-sp') === 1 ? 0 : +b.getAttribute('data-sp')); }; });
  }
  function keysHTML() { return '<div class="gm-keys">' + ['ä', 'ö', 'ü', 'ß'].map(function (k) { return '<button type="button" data-k="' + k + '">' + k + '</button>'; }).join('') + '</div>'; }
  function wireKeys(box) {
    [].forEach.call(box.querySelectorAll('[data-k]'), function (b) {
      b.onclick = function () {
        var inp = box.querySelector('.gm-in:focus') || box.querySelector('.gm-in'); if (!inp) return;
        var s = inp.selectionStart == null ? inp.value.length : inp.selectionStart, e = inp.selectionEnd == null ? s : inp.selectionEnd;
        if (inp.maxLength > 0 && inp.value.length - (e - s) >= inp.maxLength) inp.value = '';
        inp.value = inp.value.slice(0, s) + b.getAttribute('data-k') + inp.value.slice(e); inp.focus(); inp.dispatchEvent(new Event('input')); SFX.tap();
      };
    });
  }
  function autoSay(text, spk) { setTimeout(function () { if (st && st.alive) A.speak(text, spk); }, 350); }

  /* ---------------- رسّامو التحديات ---------------- */
  var R = {};
  R.listenType = function (box, ch, ctl) {
    var w = ch.w, say = A.wTxt(w);
    box.innerHTML = '<h3>اكتب ما تسمعه</h3>' + audioBtns() + '<input class="gm-in" placeholder="اكتب الكلمة بالألمانية" autocomplete="off" autocapitalize="off" spellcheck="false">' + keysHTML();
    var inp = box.querySelector('.gm-in'); wireAudio(box, say, 0); wireKeys(box);
    inp.oninput = function () { ctl.enable(!!inp.value.trim()); }; autoSay(say, 0);
    ctl.check = function () { var u = dn(stripArt(inp.value)), e = dn(w.de); return { ok: u === e || (e.length >= 7 && A.lev(u, e) <= 1), correct: wLabel(w), tip: w.ar }; };
  };
  R.speak = function (box, ch, ctl) {
    var w = ch.w, say = A.wTxt(w);
    box.innerHTML = '<h3>انطق هذه الكلمة</h3><div class="gm-word">' + esc(wLabel(w)) + '</div><div class="gm-mean">' + esc(w.ar || '') + '</div>' + audioBtns(false) +
      '<button type="button" class="gm-mic" aria-label="تحدّث"><i class="fas fa-microphone"></i></button><div class="gm-say"></div><div class="gm-self" style="display:none"><button type="button" class="gm-rbtn" data-y="1" style="width:auto;padding:12px 18px">نطقتها صح ✅</button><button type="button" class="gm-rbtn alt" data-y="0" style="width:auto;padding:12px 18px">أحتاج تدريبًا ❌</button></div>' +
      '<button type="button" class="gm-skip">لا أستطيع التحدث الآن</button>';
    var mic = box.querySelector('.gm-mic'), out = box.querySelector('.gm-say'), self = box.querySelector('.gm-self'); wireAudio(box, say, 0); ctl.hideCheck();
    box.querySelector('.gm-skip').onclick = function () { ctl.skip(); };
    function selfCheck() { self.style.display = 'flex'; mic.style.display = 'none'; [].forEach.call(self.querySelectorAll('button'), function (b) { b.onclick = function () { ctl.submit({ ok: b.getAttribute('data-y') === '1', correct: wLabel(w), tip: w.ar }); }; }); }
    if (!A.SR) { out.textContent = 'متصفحك لا يدعم التعرف على الصوت، قيّم نطقك بنفسك'; selfCheck(); return; }
    mic.onclick = function () {
      if (mic.classList.contains('on')) return;
      SFX.tap(); mic.classList.add('on'); out.textContent = 'أستمع إليك…';
      A.listen(stripArt(w.de), {
        interim: function (t) { out.textContent = t; },
        done: function (best, res) { mic.classList.remove('on'); out.textContent = best; ctl.submit({ ok: res.pct >= 70, correct: wLabel(w), tip: w.ar, note: 'نسبة المطابقة ' + res.pct + '%' }); },
        error: function (code) { mic.classList.remove('on'); out.textContent = code === 'no-speech' ? 'لم أسمعك، أعد المحاولة' : 'تعذّر التسجيل'; if (code === 'not-allowed' || code === 'service-not-allowed' || code === 'unsupported') selfCheck(); },
        end: function (got) { mic.classList.remove('on'); if (!got && !out.textContent) out.textContent = 'لم أسمعك، أعد المحاولة'; }
      });
    };
  };
  R.trAr2De = function (box, ch, ctl) {
    var s = ch.s;
    box.innerHTML = '<h3>ترجم إلى الألمانية</h3><div class="gm-sent">' + esc(s.ar) + '</div><input class="gm-in" placeholder="اكتب الجملة بالألمانية" autocomplete="off" autocapitalize="off" spellcheck="false">' + keysHTML();
    var inp = box.querySelector('.gm-in'); wireKeys(box); inp.oninput = function () { ctl.enable(!!inp.value.trim()); };
    ctl.check = function () { var r = A.compare(s.de, inp.value); return { ok: r.pct >= 85, correct: s.de, said: [s.de, s.spk] }; };
  };
  R.trDe2Ar = function (box, ch, ctl) {
    var s = ch.s, pick = null;
    box.innerHTML = '<h3>اختر الترجمة الصحيحة</h3>' + audioBtns() + '<div class="gm-sent de">' + esc(s.de) + '</div><div class="gm-opts">' + ch.opts.map(function (o, i) { return '<button type="button" class="gm-opt" data-i="' + i + '">' + esc(o) + '</button>'; }).join('') + '</div>';
    wireAudio(box, s.de, s.spk); autoSay(s.de, s.spk);
    [].forEach.call(box.querySelectorAll('.gm-opt'), function (b) { b.onclick = function () { SFX.tap(); [].forEach.call(box.querySelectorAll('.gm-opt'), function (x) { x.classList.remove('sel'); }); b.classList.add('sel'); pick = ch.opts[+b.getAttribute('data-i')]; ctl.enable(true); }; });
    ctl.check = function () { return { ok: pick === s.ar, correct: s.ar, said: [s.de, s.spk] }; };
  };
  R.cloze = function (box, ch, ctl) {
    var s = ch.s, toks = rawToks(s.de), c = core(toks[ch.idx]), html = toks.map(function (t, i) {
      if (i !== ch.idx) return '<span>' + esc(t) + '</span>';
      var pre = t.slice(0, t.indexOf(c)), post = t.slice(t.indexOf(c) + c.length);
      return esc(pre) + '<input class="gm-in sm" autocomplete="off" autocapitalize="off" spellcheck="false" style="width:' + Math.max(6, c.length + 2) + 'ch">' + esc(post);
    }).join(' ');
    box.innerHTML = '<h3>اسمع وأكمل الكلمة الناقصة</h3>' + audioBtns() + '<div class="gm-sent de">' + html + '</div><div class="gm-mean">' + esc(s.ar) + '</div>' + keysHTML();
    var inp = box.querySelector('.gm-in'); wireAudio(box, s.de, s.spk); wireKeys(box); inp.oninput = function () { ctl.enable(!!inp.value.trim()); }; autoSay(s.de, s.spk);
    ctl.check = function () { var u = dn(inp.value), e = dn(c); return { ok: u === e || (e.length >= 7 && A.lev(u, e) <= 1), correct: s.de, said: [s.de, s.spk] }; };
  };
  R.match = function (box, ch, ctl) {
    var pairs = ch.pairs, selL = null, selR = null, mistakes = 0, left = pairs.length;
    box.innerHTML = '<h3>وصّل كل كلمة بمعناها</h3><div class="gm-match"><div class="gm-opts" id="gmL">' + shuffle(pairs).map(function (p) { return '<button type="button" class="gm-opt ltr" data-d="' + esc(p.de) + '">' + esc(wLabel(p)) + '</button>'; }).join('') + '</div><div class="gm-opts" id="gmR">' + shuffle(pairs).map(function (p) { return '<button type="button" class="gm-opt" data-d="' + esc(p.de) + '">' + esc(p.ar || '') + '</button>'; }).join('') + '</div></div>';
    ctl.hideCheck();
    function clear(b) { if (b) b.classList.remove('sel'); }
    function tryMatch() {
      if (!selL || !selR) return;
      var a = selL, b = selR; selL = selR = null;
      if (a.getAttribute('data-d') === b.getAttribute('data-d')) { SFX.pair(); a.classList.remove('sel'); b.classList.remove('sel'); a.classList.add('done'); b.classList.add('done'); if (!--left) setTimeout(function () { ctl.submit({ ok: mistakes <= 2, correct: pairs.map(function (p) { return wLabel(p) + ' = ' + p.ar; }).join(' ، '), xp: 20 }); }, 350); }
      else { mistakes++; SFX.bad(); buzz(80); [a, b].forEach(function (x) { x.classList.add('shake'); setTimeout(function () { x.classList.remove('shake', 'sel'); }, 380); }); }
    }
    [].forEach.call(box.querySelectorAll('#gmL .gm-opt'), function (b) { b.onclick = function () { clear(selL); selL = b; b.classList.add('sel'); SFX.tap(); var p = pairs.filter(function (x) { return x.de === b.getAttribute('data-d'); })[0]; if (p) A.speak(A.wTxt(p), 0); tryMatch(); }; });
    [].forEach.call(box.querySelectorAll('#gmR .gm-opt'), function (b) { b.onclick = function () { clear(selR); selR = b; b.classList.add('sel'); SFX.tap(); tryMatch(); }; });
  };
  R.order = function (box, ch, ctl) {
    var s = ch.s, toks = rawToks(s.de), bank, ans = [], order = shuffle(toks.map(function (t, i) { return i; }));
    if (toks.length > 2) { var tries = 0; while (order.join() === toks.map(function (t, i) { return i; }).join() && tries++ < 8) order = shuffle(order); }
    box.innerHTML = '<h3>رتّب الجملة</h3>' + audioBtns() + '<div class="gm-mean">' + esc(s.ar) + '</div><div class="gm-ord"></div><div class="gm-bank"></div>';
    var ordEl = box.querySelector('.gm-ord'), bankEl = box.querySelector('.gm-bank'); wireAudio(box, s.de, s.spk);
    function paint() {
      ordEl.innerHTML = ans.map(function (i, k) { return '<button type="button" class="gm-tile" data-a="' + k + '">' + esc(toks[i]) + '</button>'; }).join('');
      bankEl.innerHTML = order.map(function (i) { return '<button type="button" class="gm-tile' + (ans.indexOf(i) > -1 ? ' used' : '') + '" data-b="' + i + '">' + esc(toks[i]) + '</button>'; }).join('');
      [].forEach.call(ordEl.querySelectorAll('[data-a]'), function (b) { b.onclick = function () { SFX.tap(); ans.splice(+b.getAttribute('data-a'), 1); paint(); }; });
      [].forEach.call(bankEl.querySelectorAll('[data-b]'), function (b) { b.onclick = function () { SFX.tap(); ans.push(+b.getAttribute('data-b')); paint(); }; });
      ctl.enable(ans.length === toks.length);
    }
    paint();
    ctl.check = function () { var got = ans.map(function (i) { return toks[i]; }).join(' '); return { ok: dn(got) === dn(s.de) && ans.map(function (i) { return core(toks[i]); }).join('|') === toks.map(core).join('|') || got === s.de, correct: s.de, said: [s.de, s.spk] }; };
  };
  R.letter = function (box, ch, ctl) {
    var w = ch.w, word = ch.word, miss = word[ch.pos], shown = word.slice(0, ch.pos) + '_' + word.slice(ch.pos + 1);
    box.innerHTML = '<h3>اكتب الحرف الناقص</h3><div class="gm-word">' + esc(shown) + '</div><div class="gm-mean">' + esc(w.ar || '') + '</div>' + audioBtns(false) + '<input class="gm-in one" maxlength="1" autocomplete="off" autocapitalize="off" spellcheck="false">' + keysHTML();
    var inp = box.querySelector('.gm-in'); wireAudio(box, A.wTxt(w), 0); wireKeys(box); inp.oninput = function () { ctl.enable(!!inp.value.trim()); };
    ctl.check = function () { return { ok: dn(inp.value) === dn(miss), correct: wLabel(w), said: [A.wTxt(w), 0] }; };
  };
  R.article = function (box, ch, ctl) {
    var w = ch.w, pick = null;
    box.innerHTML = '<h3>اختر أداة التعريف الصحيحة</h3><div class="gm-word">' + esc(stripArt(w.de)) + '</div><div class="gm-mean">' + esc(w.ar || '') + '</div><div class="gm-art">' + ['der', 'die', 'das'].map(function (a) { return '<button type="button" class="gm-opt" data-a="' + a + '">' + a + '</button>'; }).join('') + '</div>';
    [].forEach.call(box.querySelectorAll('.gm-opt'), function (b) { b.onclick = function () { SFX.tap(); [].forEach.call(box.querySelectorAll('.gm-opt'), function (x) { x.classList.remove('sel'); }); b.classList.add('sel'); pick = b.getAttribute('data-a'); ctl.enable(true); }; });
    ctl.check = function () { return { ok: pick === String(w.art).toLowerCase(), correct: wLabel(w), said: [A.wTxt(w), 0] }; };
  };
  function pickCommon(box, ch, ctl, listen) {
    var w = ch.w, pick = null;
    box.innerHTML = '<h3>' + (listen ? 'اسمع واختر الكلمة' : 'اختر المعنى الصحيح') + '</h3>' + (listen ? audioBtns() : '<div class="gm-word">' + esc(wLabel(w)) + '</div>' + audioBtns(false)) +
      '<div class="gm-opts">' + ch.opts.map(function (o, i) { return '<button type="button" class="gm-opt' + (listen ? ' ltr' : '') + '" data-i="' + i + '">' + esc(listen ? wLabel(o) : (o.ar || '')) + '</button>'; }).join('') + '</div>';
    wireAudio(box, A.wTxt(w), 0); if (listen) autoSay(A.wTxt(w), 0);
    [].forEach.call(box.querySelectorAll('.gm-opt'), function (b) { b.onclick = function () { SFX.tap(); [].forEach.call(box.querySelectorAll('.gm-opt'), function (x) { x.classList.remove('sel'); }); b.classList.add('sel'); pick = ch.opts[+b.getAttribute('data-i')]; ctl.enable(true); }; });
    ctl.check = function () { return { ok: pick === w, correct: listen ? wLabel(w) : w.ar, tip: listen ? w.ar : null, said: [A.wTxt(w), 0] }; };
  }
  R.pickMeaning = function (box, ch, ctl) { pickCommon(box, ch, ctl, false); };
  R.listenPick = function (box, ch, ctl) { pickCommon(box, ch, ctl, true); };
  R.memory = function (box, ch, ctl) {
    var cards = [], first = null, lock = false, moves = 0, left = ch.pairs.length;
    ch.pairs.forEach(function (p) { cards.push({ k: p.de, t: wLabel(p), de: true, p: p }); cards.push({ k: p.de, t: p.ar || '', de: false, p: p }); });
    cards = shuffle(cards); ctl.hideCheck();
    box.innerHTML = '<h3>طابق الأزواج <small style="font-weight:800;color:var(--mute)">(حركات: <span id="gmMv">0</span>)</small></h3><div class="gm-mem">' + cards.map(function (c, i) { return '<button type="button" class="gm-card2" data-i="' + i + '" dir="' + (c.de ? 'ltr' : 'rtl') + '">' + esc(c.t) + '</button>'; }).join('') + '</div>';
    [].forEach.call(box.querySelectorAll('.gm-card2'), function (b) {
      b.onclick = function () {
        if (lock || b.classList.contains('up') || b.classList.contains('done')) return;
        var c = cards[+b.getAttribute('data-i')]; b.classList.add('up'); SFX.tap(); if (c.de) A.speak(A.wTxt(c.p), 0);
        if (!first) { first = { b: b, c: c }; return; }
        moves++; box.querySelector('#gmMv').textContent = moves;
        var f = first; first = null;
        if (f.c.k === c.k && f.c.de !== c.de) { SFX.pair(); [f.b, b].forEach(function (x) { x.classList.remove('up'); x.classList.add('done'); }); if (!--left) setTimeout(function () { ctl.submit({ ok: true, correct: 'أنهيت اللعبة في ' + moves + ' حركة', xp: 30 }); }, 450); }
        else { lock = true; SFX.bad(); setTimeout(function () { [f.b, b].forEach(function (x) { x.classList.remove('up'); }); lock = false; }, 800); }
      };
    });
  };

  /* ---------------- القشرة: القائمة والجولة ---------------- */
  function gkey(id) { return 'lx_g_' + (A.title || '') + '_' + id; }
  function stars(id) { var n = +LS.get(gkey(id)) || 0; return '★★★'.slice(0, n) + '☆☆☆'.slice(0, 3 - n); }
  function toast(msg) { var d = document.createElement('div'); d.className = 'gm-toast'; d.textContent = msg; root.appendChild(d); setTimeout(function () { d.remove(); }, 1800); }

  function showHub() {
    if (st) st.alive = false; A.stop();
    var xp = +LS.get('lx_xp') || 0, best = +LS.get('lx_gstreak') || 0;
    root.innerHTML = '<div class="gm-hh"><button type="button" class="gm-x" id="gmClose" aria-label="إغلاق"><i class="fas fa-xmark"></i></button><h2>🎮 ألعاب الكلمات</h2><button type="button" class="gm-x" id="gmSnd" aria-label="الصوت"><i class="fas ' + (sfxOn ? 'fa-volume-high' : 'fa-volume-xmark') + '"></i></button></div>' +
      '<div class="gm-hub"><div class="gm-chips"><span class="gm-chip">⭐ نقاطك: ' + xp + '</span><span class="gm-chip">🔥 أفضل سلسلة: ' + best + '</span><span class="gm-chip">📘 ' + A.esc(A.title || 'الدرس') + '</span></div>' +
      '<button type="button" class="gm-mix" data-g="mix"><i class="fas fa-bolt"></i><span><b>جلسة مختلطة</b><small>١٠ تحديات متنوعة من كل الألعاب</small></span></button>' +
      '<div class="gm-grid">' + GAMES.map(function (g) {
        var ok = canPlay(g.id);
        return '<button type="button" class="gm-g" data-g="' + g.id + '"' + (ok ? '' : ' disabled') + '><span class="gm-gi" style="background:' + g.c + '"><i class="fas ' + g.i + '"></i></span><b>' + g.t + '</b><small>' + (ok ? g.d : NEED[g.id]) + '</small><span class="gm-stars">' + (ok ? stars(g.id) : '') + '</span></button>';
      }).join('') + '</div><button type="button" class="gm-rbtn" id="gmEndHub" style="margin-top:18px">أنهيت الألعاب؟ إنهاء الدرس ←</button></div>';
    $q('#gmClose').onclick = close;
    $q('#gmEndHub').onclick = function () { SFX.tap(); if (A.endLesson) A.endLesson(); };
    $q('#gmSnd').onclick = function () { sfxOn = !sfxOn; LS.set('lx_sfx', sfxOn ? '1' : '0'); showHub(); if (sfxOn) SFX.ok(); };
    [].forEach.call(root.querySelectorAll('[data-g]'), function (b) { b.onclick = function () { SFX.tap(); start(b.getAttribute('data-g')); }; });
    /* تجهيز أصوات الكلمات في الخلفية */
    words().forEach(function (w) { A.prefetch(A.wTxt(w), 0); });
  }
  function $q(s) { return root.querySelector(s); }
  function close() { if (st) st.alive = false; A.stop(); if (root) root.remove(); root = null; }

  function start(id) {
    var q = buildQueue(id);
    if (!q.length) { toast('لا توجد بيانات كافية لهذه اللعبة'); return; }
    st = { id: id, queue: q, total: q.length, done: 0, xp: 0, ok: 0, bad: 0, streak: 0, bestStreak: 0, t0: Date.now(), alive: true };
    root.innerHTML = '<div class="gm-top"><button type="button" class="gm-x" id="gmQuit" aria-label="خروج"><i class="fas fa-xmark"></i></button><div class="gm-bar"><i id="gmBar"></i></div><div class="gm-hearts" style="color:var(--mute,#777)"><span id="gmH"></span></div></div><div class="gm-body"><div class="gm-box" id="gmBox"></div></div><div class="gm-foot" id="gmFoot"><div class="gm-fb" id="gmFb" style="display:none"></div><button type="button" class="gm-chk" id="gmChk" disabled>تحقّق</button></div>';
    $q('#gmQuit').onclick = function () { if (confirm('هل تريد الخروج؟ سيضيع تقدمك في هذه الجولة.')) showHub(); };
    next();
  }
  function paintTop() { $q('#gmBar').style.width = Math.round(100 * st.done / st.total) + '%'; $q('#gmH').textContent = st.done + ' / ' + st.total; }

  function next() {
    if (!st.alive) return;
    if (!st.queue.length) return finish();
    var ch = st.queue[0], box = $q('#gmBox'), foot = $q('#gmFoot'), chk = $q('#gmChk'), fb = $q('#gmFb'), state = 'answer', res = null;
    paintTop(); A.stop();
    foot.className = 'gm-foot'; fb.style.display = 'none'; chk.style.display = ''; chk.disabled = true; chk.textContent = 'تحقّق';
    box.parentNode.scrollTop = 0;
    var ctl = {
      check: null,
      enable: function (b) { if (state === 'answer') chk.disabled = !b; },
      hideCheck: function () { chk.style.display = 'none'; },
      skip: function () { st.queue.shift(); next(); },
      submit: function (r) {
        if (state !== 'answer') return; state = 'feedback'; res = r; chk.style.display = ''; chk.disabled = false;
        var good = !!r.ok, msg;
        if (good) {
          st.ok++; st.streak++; if (st.streak > st.bestStreak) st.bestStreak = st.streak;
          var gain = r.xp || (10 + (st.streak >= 3 ? 5 : 0)); st.xp += gain; st.done++;
          msg = STREAKS[st.streak] || rnd(PRAISE);
          (STREAKS[st.streak] ? SFX.streak : SFX.ok)(); buzz(30);
          fb.innerHTML = '<b>' + msg + '</b><small>+' + gain + ' نقطة' + (r.note ? ' · ' + A.esc(r.note) : '') + (r.tip ? ' · ' + A.esc(r.tip) : '') + '</small>';
          foot.className = 'gm-foot ok';
        } else {
          st.bad++; st.streak = 0; st.done++; SFX.bad(); buzz([60, 40, 60]);
          fb.innerHTML = '<b>' + rnd(OOPS) + '</b><small>الإجابة الصحيحة: <span class="de">' + A.esc(r.correct) + '</span>' + (r.tip ? '<br>' + A.esc(r.tip) : '') + (r.note ? ' · ' + A.esc(r.note) : '') + '</small>';
          foot.className = 'gm-foot bad';
        }
        fb.style.display = ''; chk.textContent = st.queue.length > 1 ? 'متابعة' : 'عرض الدرجة';
        paintTop();
        if (r.said) A.speak(r.said[0], r.said[1]);
        chk.focus();
      }
    };
    chk.onclick = function () {
      if (state === 'answer') { if (ctl.check) ctl.submit(ctl.check()); }
      else { st.queue.shift(); next(); }
    };
    box.innerHTML = ''; R[ch.type](box, ch, ctl);
    var inp = box.querySelector('input.gm-in'); if (inp) setTimeout(function () { try { inp.focus({ preventScroll: true }); } catch (e) {} }, 60);
  }

  function finish() {
    st.alive = false; A.stop();
    var tot = st.ok + st.bad, acc = tot ? Math.round(100 * st.ok / tot) : 100, n = acc >= 90 ? 3 : acc >= 70 ? 2 : 1, secs = Math.round((Date.now() - st.t0) / 1000);
    if (st.id !== 'mix') { var prev = +LS.get(gkey(st.id)) || 0; if (n > prev) LS.set(gkey(st.id), String(n)); }
    LS.set('lx_xp', String((+LS.get('lx_xp') || 0) + st.xp)); if (st.bestStreak > (+LS.get('lx_gstreak') || 0)) LS.set('lx_gstreak', String(st.bestStreak));
    root.innerHTML = '<div class="gm-body"><div class="gm-res"><div class="big">' + (acc >= 90 ? '🏆' : acc >= 70 ? '🎉' : acc >= 40 ? '👍' : '💪') + '</div><h2>' + (acc >= 90 ? 'أداء مذهل!' : acc >= 70 ? 'أحسنت!' : acc >= 40 ? 'جيد، واصل التدرّب' : 'بداية جيدة، حاول مرة أخرى') + '</h2>' +
      '<div class="gm-stars" style="font-size:2rem;margin:4px 0 6px">' + '★★★'.slice(0, n) + '☆☆☆'.slice(0, 3 - n) + '</div>' +
      '<div style="font-size:3.2rem;font-weight:900;color:var(--primary,#dc143c);line-height:1.1">' + acc + '%</div><p>درجتك: ' + st.ok + ' إجابة صحيحة من ' + tot + '</p>' +
      '<div class="gm-rstats"><div><b>' + st.xp + '</b>نقطة</div><div><b>' + st.bestStreak + '</b>أفضل سلسلة</div><div><b>' + secs + 'ث</b>الوقت</div></div>' +
      '<button type="button" class="gm-rbtn" id="gmEnd">إنهاء الدرس ←</button><button type="button" class="gm-rbtn alt" id="gmAgain">العب مرة أخرى</button><button type="button" class="gm-rbtn alt" id="gmHub">اختر لعبة أخرى</button></div></div>';
    var id = st.id; $q('#gmAgain').onclick = function () { SFX.tap(); start(id); }; $q('#gmHub').onclick = function () { SFX.tap(); showHub(); };
    $q('#gmEnd').onclick = function () { SFX.tap(); if (A.endLesson) A.endLesson(); };
    SFX.win(); if (acc >= 70) confetti(); buzz([80, 50, 80]);
  }

  /* ---------------- نقطة الدخول ---------------- */
  window.LXGames = {
    state: function () { return st; },
    open: function (api) {
      A = api;
      if (!document.getElementById('gm-css')) { var s = document.createElement('style'); s.id = 'gm-css'; s.textContent = CSS; document.head.appendChild(s); }
      if (root) root.remove();
      root = document.createElement('div'); root.className = 'gm-ov'; root.setAttribute('dir', 'rtl'); A.app.appendChild(root);
      document.addEventListener('keydown', onKey);
      showHub();
    }
  };
  function onKey(e) {
    if (!root) { document.removeEventListener('keydown', onKey); return; }
    if (e.key === 'Enter') { var c = root.querySelector('#gmChk'); if (c && !c.disabled && c.style.display !== 'none') { e.preventDefault(); c.click(); } }
    if (e.key === 'Escape') { var q = root.querySelector('#gmClose'); if (q) q.click(); }
  }
})();
