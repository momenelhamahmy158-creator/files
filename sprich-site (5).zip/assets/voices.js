
/* ===== محمّل أصوات Piper المشترك: يعمل في كل صفحات المدونة ويحمّل الأصوات في الخلفية عند أول تفاعل ===== */
(function () {
  if (window.LXP) return;
  var PRELOAD = true;   /* غيّرها إلى false لإيقاف التحميل الخلفي في الصفحات الأخرى */
  var VOICES = ['de_DE-thorsten-medium', 'de_DE-karlsson-low'];
  var URLS = ['https://cdn.jsdelivr.net/npm/@mintplex-labs/piper-tts-web@1.0.4/+esm', 'https://esm.sh/@mintplex-labs/piper-tts-web@1.0.4'];
  var modP = null, dl = {};
  function mod() {
    if (!modP) {
      modP = URLS.reduce(function (p, u) { return p.catch(function () { return import(u); }); }, Promise.reject(new Error('start')))
        .then(function (m) { return (m && m.predict) ? m : (m && m.default); });
      modP.catch(function () { modP = null; });
    }
    return modP;
  }
  function fetchVoice(v) {
    if (dl[v]) return dl[v];
    var d = dl[v] = { loaded: 0, total: 0, done: false, cbs: [] };
    d.p = mod().then(function (m) {
      if (!m || !m.predict || !m.download) throw new Error('module');
      /* لا نعيد التحميل لو الصوت محفوظ في الجهاز */
      return (m.stored ? m.stored() : Promise.resolve([])).catch(function () { return []; }).then(function (have) {
        if (have && have.indexOf(v) > -1) { d.done = true; return m; }
        return m.download(v, function (pr) {
          if (pr && pr.total > 5e6) { d.loaded = pr.loaded; d.total = pr.total; d.cbs.forEach(function (fn) { fn(); }); }
        }).then(function () { d.done = true; return m; });
      });
    });
    d.p.catch(function () { delete dl[v]; });
    return d;
  }
  window.LXP = {
    VOICES: VOICES, started: false,
    /* يرجع Promise بالمكتبة بعد تحميل الأصوات. onProg(0..1) تقدّم التحميل */
    load: function (voices, onProg) {
      var ds = voices.map(fetchVoice);
      function emit() { if (onProg) onProg(ds.reduce(function (a, d) { return a + (d.done ? 1 : (d.total ? d.loaded / d.total : 0)); }, 0) / ds.length); }
      ds.forEach(function (d) { d.cbs.push(emit); });
      emit();
      return Promise.all(ds.map(function (d) { return d.p; })).then(function (r) { emit(); return r[0]; });
    }
  };
  function bg() {
    if (window.LXP.started) return; window.LXP.started = true;
    if (!PRELOAD) return;
    var c = navigator.connection || {};
    if (c.saveData || c.type === 'cellular') return;
    var run = function () { window.LXP.load(VOICES).catch(function () {}); };
    if (window.requestIdleCallback) requestIdleCallback(run, { timeout: 4000 }); else setTimeout(run, 1500);
  }
  ['pointerdown', 'keydown', 'touchstart', 'scroll', 'mousemove'].forEach(function (ev) { addEventListener(ev, bg, { passive: true, once: true }); });
})();
