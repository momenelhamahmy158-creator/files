#!/usr/bin/env python3
"""يبني lessons/index.json من كل ملفات lessons/*.json ويُنشئ sitemap.xml (اختياري).

الاستخدام (من مجلد المشروع):
    python tools/build_index.py
    python tools/build_index.py --site https://your-name.pages.dev
"""
import json, glob, os, sys, datetime
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
site = ''
if '--site' in sys.argv:
    site = sys.argv[sys.argv.index('--site') + 1].rstrip('/')
items = []
for p in sorted(glob.glob(os.path.join(root, 'lessons', '*.json'))):
    if os.path.basename(p) == 'index.json':
        continue
    j = json.load(open(p, encoding='utf-8'))
    items.append({
        'slug': j['slug'], 'title': j['title'], 'level': j.get('level', ''),
        'cats': j.get('cats', []), 'scene': j.get('scene', 'day'),
        'time': j.get('time') or datetime.date.fromtimestamp(os.path.getmtime(p)).isoformat(),
    })
items.sort(key=lambda x: x['time'], reverse=True)
json.dump({'lessons': items}, open(os.path.join(root, 'lessons', 'index.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(len(items), 'lessons indexed')
if site:
    urls = [site + '/' + p for p in ('', 'lessons.html', 'explain.html', 'placement.html', 'shadowing.html', 'achievements.html', 'install.html', 'about.html', 'contact.html', 'privacy.html', 'terms.html')]
    urls += [site + '/lesson.html?l=' + i['slug'] for i in items]
    xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + \
          ''.join('  <url><loc>%s</loc></url>\n' % u.replace('&', '&amp;') for u in urls) + '</urlset>\n'
    open(os.path.join(root, 'sitemap.xml'), 'w', encoding='utf-8').write(xml)
    print('sitemap.xml written')
